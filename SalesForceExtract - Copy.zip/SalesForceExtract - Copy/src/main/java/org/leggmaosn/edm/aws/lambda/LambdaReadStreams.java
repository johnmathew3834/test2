package org.leggmaosn.edm.aws.lambda;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.leggmaosn.edm.entity.Contact;
import org.leggmason.edm.utils.handler.UnProcessedDataHandler;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.KinesisEvent;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;


public class LambdaReadStreams  implements RequestHandler<KinesisEvent, String> {
	Gson gson = new GsonBuilder().setPrettyPrinting().create();
	AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	Type contactListType = new TypeToken<ArrayList<Contact>>(){}.getType();
	@Override
    public String handleRequest(KinesisEvent event, Context context) {
		try {
		UnProcessedDataHandler unProcessedDataHandler = new UnProcessedDataHandler();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		String recordArray=event.getRecords().stream().map(kinesisEventRecord ->{return new String(kinesisEventRecord.getKinesis().getData().array());}).collect(Collectors.joining(","));
		System.out.println(recordArray);
		List<Contact> contactList = gson.fromJson("["+recordArray+"]",contactListType);
		for(Contact contact : contactList) {
		    System.out.println(contact.getAccount_id());
		}
		
		DynamoDBMapper mapper = new DynamoDBMapper(client);
		List<FailedBatch> failedBatches = mapper.batchSave(contactList);
		for (FailedBatch batch : failedBatches) {
			Map<String, List<WriteRequest>> items = batch.getUnprocessedItems();
			for (Map.Entry<String, List<WriteRequest>> entry : items.entrySet()) {
				 
			    // Feel free to ignore me since it looks like you're only deleting
			    // items from a single table?
			    String tableName = entry.getKey();
			 
			    for (WriteRequest request : entry.getValue()) {
			      Map<String, AttributeValue> key = request.getDeleteRequest().getKey();
			      //log.error("  (table:" + tableName + ", key:" + key + ")");
			      System.out.println("  (table:" + tableName + ", key:" + key + ")");
			    }
			  }
		}
		
		System.out.println("`````````````````````````"+contactList.size());
		}catch (AmazonServiceException ase) {
		    System.err.println("Could not complete operation");
		    System.err.println("Error Message:  " + ase.getMessage());
		    System.err.println("HTTP Status:    " + ase.getStatusCode());
		    System.err.println("AWS Error Code: " + ase.getErrorCode());
		    System.err.println("Error Type:     " + ase.getErrorType());
		    System.err.println("Request ID:     " + ase.getRequestId());

		} catch (AmazonClientException ace) {
		    System.err.println("Internal error occurred communicating with DynamoDB");
		    System.out.println("Error Message:  " + ace.getMessage());
		}
		return "success suresh....";
	}
	
	   public static void main(String args[]) {
		      ArrayList <String> arrayList = new ArrayList<String>();
		      arrayList.add("JavaFX");
		      arrayList.add("HBase");
		      arrayList.add("JOGL");
		      arrayList.add("WebGL");
		      JSONArray jsArray2 = new JSONArray(arrayList);
		      System.out.println(jsArray2.toString());
		      List<Integer> numbers = Arrays.asList(1, 2, 3, 4);
		      String commaSeparatedNumbers = numbers.stream()
		          .map(i -> i.toString())
		          .collect(Collectors.joining(","));
		      System.out.println(commaSeparatedNumbers);
		   }

}
