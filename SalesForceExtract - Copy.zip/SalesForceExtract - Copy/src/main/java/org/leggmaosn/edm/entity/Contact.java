package org.leggmaosn.edm.entity;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "contact")
public class Contact implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	/*private String ID;
	private String ACCOUNTID;
	private String isdeleted;
	private String REGIONAL_DIRECTOR__C;
	private String STATUS__C;
	private String CHANNEL__C;
	private String CLIENT_SERVICE_MANAGER__C;
	private String COMPANY_REGION__C;
	private String CONTACT_CHANNEL_DERIVED__C;
	private String CONTACT_SALES_DIRECTOR__C;
	private String CONTACT_TYPE__C;
	private String CONTACT_ZONE__C;
	private String SystemModstamp;
	private String CreatedDate;*/
	private String id;
	private String account_id;
	private String isdeleted;
	private String regional_director__c;
	private String status__c;
	private String channel__c;
	private String client_service_manager__c;
	private String company_region__c;
	private String contact_channel_derived__c;
	private String contact_sales_director__c;
	private String contact_type__c;
	private String contact_zone__c;
	private String systemmodstamp;
	private String createddate;
	
	@DynamoDBHashKey
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@DynamoDBAttribute
	public String getAccount_id() {
		return account_id;
	}
	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}
	
	@DynamoDBAttribute
	public String getIsdeleted() {
		return isdeleted;
	}
	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}
	
	@DynamoDBAttribute
	public String getRegional_director__c() {
		return regional_director__c;
	}
	public void setRegional_director__c(String regional_director__c) {
		this.regional_director__c = regional_director__c;
	}
	
	@DynamoDBAttribute
	public String getStatus__c() {
		return status__c;
	}
	public void setStatus__c(String status__c) {
		this.status__c = status__c;
	}
	
	@DynamoDBAttribute
	public String getChannel__c() {
		return channel__c;
	}
	public void setChannel__c(String channel__c) {
		this.channel__c = channel__c;
	}
	
	@DynamoDBAttribute
	public String getClient_service_manager__c() {
		return client_service_manager__c;
	}
	public void setClient_service_manager__c(String client_service_manager__c) {
		this.client_service_manager__c = client_service_manager__c;
	}
	
	@DynamoDBAttribute
	public String getCompany_region__c() {
		return company_region__c;
	}
	public void setCompany_region__c(String company_region__c) {
		this.company_region__c = company_region__c;
	}
	
	@DynamoDBAttribute
	public String getContact_channel_derived__c() {
		return contact_channel_derived__c;
	}
	public void setContact_channel_derived__c(String contact_channel_derived__c) {
		this.contact_channel_derived__c = contact_channel_derived__c;
	}
	
	@DynamoDBAttribute
	public String getContact_sales_director__c() {
		return contact_sales_director__c;
	}
	public void setContact_sales_director__c(String contact_sales_director__c) {
		this.contact_sales_director__c = contact_sales_director__c;
	}
	
	@DynamoDBAttribute
	public String getContact_type__c() {
		return contact_type__c;
	}
	public void setContact_type__c(String contact_type__c) {
		this.contact_type__c = contact_type__c;
	}
	
	@DynamoDBAttribute
	public String getContact_zone__c() {
		return contact_zone__c;
	}		
	public void setContact_zone__c(String contact_zone__c) {
		this.contact_zone__c = contact_zone__c;
	}
	
	@DynamoDBAttribute
	public String getSystemmodstamp() {
		return systemmodstamp;
	}
	public void setSystemmodstamp(String systemmodstamp) {
		this.systemmodstamp = systemmodstamp;
	}
	
	@DynamoDBAttribute
	public String getCreateddate() {
		return createddate;
	}
	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}
}
