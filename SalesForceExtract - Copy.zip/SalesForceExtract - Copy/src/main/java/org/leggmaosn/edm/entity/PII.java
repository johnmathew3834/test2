package org.leggmaosn.edm.entity;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "piidata")
public class PII implements Serializable {
	private static final long serialVersionUID = 1L;
	private String name;
	private String propertyAddress;
	private String creditCard;
	private String creditCardExpiry;
	private String socialSecurityNumber;
	private String principal;
	private String interestRate;
	private String term;
	private String type;
	
	@DynamoDBHashKey
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@DynamoDBHashKey
	public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	
	@DynamoDBHashKey
	public String getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	
	@DynamoDBHashKey
	public String getCreditCardExpiry() {
		return creditCardExpiry;
	}
	public void setCreditCardExpiry(String creditCardExpiry) {
		this.creditCardExpiry = creditCardExpiry;
	}
	
	@DynamoDBHashKey
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}
	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}
	
	@DynamoDBHashKey
	public String getPrincipal() {
		return principal;
	}
	public void setPrincipal(String principal) {
		this.principal = principal;
	}
	
	@DynamoDBHashKey
	public String getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	
	@DynamoDBHashKey
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	
	@DynamoDBHashKey
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}
