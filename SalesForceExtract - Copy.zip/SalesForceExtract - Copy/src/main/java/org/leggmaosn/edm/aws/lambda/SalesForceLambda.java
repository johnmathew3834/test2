package org.leggmaosn.edm.aws.lambda;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.joda.time.DateTime;
import org.joda.time.DateTimeComparator;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.leggmason.edm.utils.DBService;
import org.leggmason.edm.utils.KinesisClient;
import org.leggmason.edm.utils.SalesForceExtract;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.sforce.soap.partner.PartnerConnection;

public class SalesForceLambda implements RequestHandler<Object, String> {
	@Override
    public String handleRequest(Object input, Context context) {
        //context.getLogger().log("Input: " + input);
		int expectingMinutes=240000;//four minutes
        int remainingTime=context.getRemainingTimeInMillis();
        DBService service = new DBService();
		String getTime=service.getOrUpdateData(false,"");
		DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		DateTime dateTime = DateTime.parse(getTime,dateTimeFormatter);
		if(DateTimeComparator.getInstance().compare(dateTime, new DateTime())>=0) {
			System.out.println("Time exceeding : "+dateTime +" : "+DateTimeComparator.getInstance());
			return "time exceeding";
		}
		
		String startDate=dateTime.plusDays(1).toString(dateTimeFormatter);
		String endDate=dateTime.plusDays(5).toString(dateTimeFormatter);
		System.out.println("EndDate"+endDate);
        Boolean isDeletedRecord=Boolean.TRUE;
		String version="v39.0";
		String INIT_URL = isDeletedRecord? String.format("services/data/%1$s/queryAll/?q=",version) : String.format("services/data/%1$s/query/?q=",version);
		SalesForceExtract salesForceExtract = new SalesForceExtract();
		String data = "";
		PartnerConnection connection = null;
		try {
		connection = salesForceExtract.getConnection("https://test.salesforce.com/services/Soap/u/39.0","edmsfdc@leggmason.com.uat","Duke$Ha$$ardPremiere1975!fAwGZHXPJl4MVp4fenJDwqOuu");
		String accessToken=salesForceExtract.getAccesToken(connection);
		System.out.println(accessToken);
		System.out.println(salesForceExtract.QUERY.replaceAll("#START_Date_Time#", startDate).replaceAll("#END_Date_Time#", endDate));
		String queryString = salesForceExtract.getEncodedURL(salesForceExtract.QUERY.replaceAll("#START_Date_Time#", startDate).replaceAll("#END_Date_Time#", endDate));
		System.out.println(queryString);
		String firstRequest=salesForceExtract.buildQueryURL(connection,true,"",queryString,INIT_URL);
		data = salesForceExtract.querySalesForce(firstRequest,accessToken);
		JSONObject json = new JSONObject(data);//JSONArray jArray = (JSONArray)
		List<String> lst =new ArrayList<>();
		
		Consumer<Object> convertEventRecordToJson = new Consumer<Object>() {
		    public void accept(Object object) {
		    	Map<String, Object> row = (Map)object;
		    	lst.add("{\"id\":\""+row.get("Id")+"\",\"account_id\":\""+row.get("AccountId")+"\",\"isdeleted\":\""+row.get("IsDeleted")+"\",\"regional_director__c\":\""+row.get("Regional_Director__c")+"\",\"status__c\":\""+row.get("Status__c")+"\",\"channel__c\":\""+row.get("Channel__c")+"\",\"client_service_manager__c\":\""+row.get("Client_Service_Manager__c")+"\",\"company_region__c\":\""+row.get("Company_Region__c")+"\",\"contact_channel_derived__c\":\""+row.get("Contact_Channel_Derived__c")+"\",\"contact_sales_director__c\":\""+row.get("Contact_Sales_Director__c")+"\",\"contact_type__c\":\""+row.get("Contact_Type__c")+"\",\"contact_zone__c\":\""+row.get("Contact_Zone__c")+"\",\"createddate\":\""+row.get("CreatedDate")+"\",\"systemmodstamp\":\""+row.get("SystemModstamp")+"\"}");
		    };
		};
		 (((JSONArray)json.getJSONArray("records")).toList()).forEach(convertEventRecordToJson);
		 
		 KinesisClient cli = new KinesisClient();
		 cli.run(lst);
		 if(remainingTime<=expectingMinutes) {
			String store=salesForceExtract.nextURL(json);
			return "Pending_to_Process";
		 }
		 while(null != salesForceExtract.nextURL(json)) {
			 lst.clear();
			 queryString = salesForceExtract.buildQueryURL(connection,false,salesForceExtract.nextURL(json),"",null);
			 data = salesForceExtract.querySalesForce(queryString, accessToken);
			 json = new JSONObject(data);
			 (((JSONArray)json.getJSONArray("records")).toList()).forEach(convertEventRecordToJson);
			 cli.run(lst);
		 }
		 service.getOrUpdateData(true, endDate);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		 
		 
        return "Hello from Lambda";
    }
	

	
	

	
	

}
