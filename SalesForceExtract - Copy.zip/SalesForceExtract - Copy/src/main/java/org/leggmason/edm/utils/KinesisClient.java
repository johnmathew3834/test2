package org.leggmason.edm.utils;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import org.leggmason.edm.utils.handler.UnProcessedDataHandler;

import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.PutRecordsRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.PutRecordsResult;

public class KinesisClient {
	private static AmazonKinesis client = null;
	
	public static AmazonKinesis getConnection() {
		if(null == client) {
			client = AmazonKinesisClientBuilder.standard().withRegion("us-east-1").build();
		}
		return client;
	}
	public void pushData(AmazonKinesis kinesisClient, List<String> msgList) {
		UnProcessedDataHandler unProcessedDataHandler = new UnProcessedDataHandler();
		PutRecordsRequest putRecordsRequest  = new PutRecordsRequest();
        putRecordsRequest.setStreamName("lm-edm-poc-ds-dev02");
        List<PutRecordsRequestEntry> putRecordsRequestEntryList  = new ArrayList<>(); 
        int i=1;   
        PutRecordsResult putRecordsResult=null;
        for (String msg: msgList) {
        	System.out.println(msg);        	
            PutRecordsRequestEntry putRecordsRequestEntry  = new PutRecordsRequestEntry();
            putRecordsRequestEntry.setData(ByteBuffer.wrap(msg.getBytes()));
            putRecordsRequestEntry.setPartitionKey(String.format("partitionKey-%s", msg.split(",")[0]));
            putRecordsRequestEntryList.add(putRecordsRequestEntry); 
            if(i%400==0 || i==msgList.size()) {
            	putRecordsRequest.setRecords(putRecordsRequestEntryList);
                putRecordsResult  = kinesisClient.putRecords(putRecordsRequest);
                putRecordsResult.getRecords();
                putRecordsRequestEntryList  = new ArrayList<>(); 
            }
            if (null  != putRecordsResult && putRecordsResult.getFailedRecordCount()>0) {
            	unProcessedDataHandler.unprocessedKinesisData(putRecordsResult);
            }
            System.out.println("i size "+i);
            i++;
        }

        		
	}
	
	public void run(List<String> msgList) {
		System.out.println("Put Result - start");
		pushData(getConnection(), msgList);
		System.out.println("msgList size "+msgList.size());
		System.out.println("Put Result - end");
	}
}
