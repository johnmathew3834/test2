package org.leggmason.edm.utils.handler;

import java.util.List;

import com.amazonaws.services.kinesis.model.PutRecordsResult;
import com.amazonaws.services.kinesis.model.PutRecordsResultEntry;

public class UnProcessedDataHandler {
	
	public void unprocessedKinesisData(PutRecordsResult putRecordsResult) {
		List<PutRecordsResultEntry> putRecordsResultEntryList = putRecordsResult.getRecords();
		putRecordsResultEntryList.forEach(putRecordsResultEntry -> {
			if(true) {}
			putRecordsResultEntry.getErrorCode();
			
		});
	}

}
