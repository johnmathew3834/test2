package org.leggmason.edm.utils.security;

import java.util.Base64;

/**
  * DecryptUtil Object has decrypt method to decrypt encoded passwords
  */
public class DecryptUtil {

  /**
    * decryptBase64 function takes password with base64 encryption
    * @param encryptedPassword
    * @return decrypted orignal password
    */

  public static String decryptCode(String encryptedPassword){
	byte[] decodedArray = Base64.getDecoder().decode(encryptedPassword.getBytes());
    String byesToString = new String(decodedArray);
    return byesToString;
  }

  public static void main(String[] args) {
	System.out.println(decryptCode("RHVrZSRIYSQkYXJkUHJlbWllcmUxOTc1IWZBd0daSFhQSmw0TVZwNGZlbkpEd3FPdXU="));
}

}


//Duke$Ha$$ardPremiere1975!fAwGZHXPJl4MVp4fenJDwqOuu