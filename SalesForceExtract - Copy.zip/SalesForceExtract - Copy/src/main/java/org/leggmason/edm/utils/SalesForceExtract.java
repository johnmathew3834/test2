package org.leggmason.edm.utils;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.javatuples.Pair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sforce.soap.partner.Connector;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;

public class SalesForceExtract {

	  String HEADER_AUTH = "Authorization";
	  String HEADER_OAUTH = "Bearer ";
	  String CONTENT_TYPE_APPLICATION_JSON = "application/json";
	  String HEADER_ACCEPT = "Accept";	  
	  String NEXT_RECORD_URL = "";
	  //String QUERY="Select ID,ACCOUNTID,isdeleted,AFFILIATE__C,ALTERNATE_TERRITORY_LOCKED__C,ASSISTANTNAME,ASST_TITLE__C,BDO_DIFFERENT_FROM_COMPANY__C,BIRTHDATE,BP_ADVISOR_TIER__C,BP_HIGH_NET_WORTH__C,BP_HIGHEST_OPPORTUNITY__C,BP_PLAN_FOR_SUCCESS__C,BROKERAGE__C,CHANNEL__C,CLIENT_INTERESTS__C,CLIENT_SERVICE_MANAGER__C,COMMENTS__C,COMPANY_REGION__C,CONTACT_CHANNEL_DERIVED__C,CONTACT_LAST_ACTIVITY_DATE__C,CONTACT_NEXT_ACTIVITY_DATE__C,CONTACT_POSITION__C,CONTACT_SALES_DIRECTOR__C,CONTACT_TYPE__C,CONTACT_ZONE__C,CONTROL_FUNCTION__C,CRD__C,CREATEDBYID,CREATEDDATE,CURRENT_AUM__C,DO_NOT_MARKET_TO__C,DONOTCALL,DST_SC_CONTACT_LOCK__C,DST_SC_EMAIL__C,DST_SC_FIRSTNAME__C,DST_SC_LASTNAME__C,DST_SC_MERGE_ID__C,DST_SC_MERGE_TYPE__C,DST_SC_MIDDLENAME__C,DST_SC_NICKNAME__C,DST_SC_PHONE__C,DST_SC_SALUTATION__C,DST_SC_SUFFIX__C,EMAIL,EMAIL_2__C,EP_FA_RANKING__C,FA_DISCRETIONARY__C,FA_RECOMMENDATION__C,FAX,FIRM_COMMENTS__C,FIRM_MODEL__C,FIRST_TRADE_DATE__C,HASOPTEDOUTOFEMAIL,HASOPTEDOUTOFMAIL__C,HIRE_DATE__C,INTEGRATIONID__C,IW_BDA__C,LAST_TRADE_DATE__C,LASTMODIFIEDBYID,LASTMODIFIEDDATE,LICENSES_HELD__C,MAILING_ADDRESS_1__C,MARKETING_EMAIL_OPT_OUT__C,MIDDLE_NAME__C,MOBILEPHONE,MUTUAL_FUND__C,MX_DO_NOT_OVERWRITE_DATA__C,MX_MATRIX_CONTACT_ID__C,NAME,NICKNAME__C,OWNERID,PHONE,PRIMARY_TEAM_CONTACT__C,PRIMARY_TERRITORY__C,PRIMARY_TERRITORY_LOCKED__C,R12_REDEMPTIONS__C,R12_SALES__C,RECORDTYPEID,REGION__C,REGIONAL_DIRECTOR__C,RETIREMENT_PLATFORMS_USED__C,RETIREMENT_SEGMENTATION__C,RETIREMENT_TIER__C,SALUTATION__C,SMA_DUAL__C,SMA_SINGLE__C,STATUS__C,SUFFIX__C,TEAM__C,TERRITORY_2_ZONE__C,TERRITORY_LOOKUP_ALTERNATE__C,TERRITORY_LOOKUP_PRIMARY__C,TITLE,UMA__C,UPDATE_STATUS__C,YTD_REDEMPTIONS__C,YTD_SALES__C,ACTIVE_LOOKUP__C,ANALYTICS_ADOPTION__C,ASSISTANTPHONE,ASST_EMAIL__C,BESPOKE_CLIENT_REPORTING__C,BP_LEAD_LEGG_MASON_SALESPERSON__C,BUSINESS_LINE_ASSOCIATION__C,BUSINESS_LINE_MAILING_EXCLUSION__C,CENTER_OF_INFLUENCE__C,CLIENT_DEFINED_REGION__C,CONFIRMATION_STATEMENTS__C,CONTACT_ADDRESS_DIFFERENT_FROM_COMPANY__C,CONTACT_DEPARTMENT__C,CONTACT_ID__C,CONTACT_INTERNAL_SEGMENTATION__C,CONTACT_SALESFORCE_ID__C,CONTACT_WEBSITE__C,CONTRACT_ROLES__C,CONTROLLED_BY_OFFICE_ALTERNATE__C,CONTROLLED_BY_OFFICE_PRIMARY__C,CRM_ADOPTION__C,CRM_DIFFERENT_FROM_COMPANY__C,DEPARTMENT,DESCRIPTION,EMPLOYMENT_HISTORY__C,FLASH_RECIPIENT__C,HASOPTEDOUTOFFAX,INACTIVE_LOOKUP__C,JPN_ADDRESS2__C,JPN_CHKOUTOFCONTACT__C,JPN_FURIGANA__C,JPN_GENDER__C,JPN_IDO__C,JPN_IDOBI__C,JPN_RESIGNDATE__C,JPN_SENTEI__C,JPN_SENTEIMAIN__C,JPN_SONOTA__C,JPN_SUISHIN__C,JPN_SUISHINMAIN__C,JPN_TAISHOKU__C,JPN_YAKUIN__C,JPN_YUBINBANGO__C,KEY_CONTACT__C,LANGUAGE__C,LANGUAGE2__C,LAST_ACTIVITY_DATE_BDO__C,LAST_ACTIVITY_DATE_CRM__C,MAILING_ADDRESS_SAME_AS_CONTACT__C,MailingStreet,MailingCity,MailingState,MailingPostalCode,MailingCountry,MASTER_ASSET_CLASS_COVERAGE__C,MX_CONTACT_FSA_REFERENCE__C,MX_JOB_TITLE__C,OFFICE_COMMENTS__C,OtherStreet,OtherCity,OtherState,OtherPostalCode,OtherCountry,OTHERPHONE,PRIOR_YEAR_2_REDEMPTIONS__C,PRIOR_YEAR_2_SALES__C,PRIOR_YEAR_AUM__C,PRIOR_YEAR_REDEMPTIONS__C,PRIOR_YEAR_SALES__C,REPORTSTOID,RESEARCH_ANALYST_TYPE__C,RESEARCH_COVERAGE_COMMENTS__C,SECONDARY_INTERESTS_AFFILIATES__C,SILVERPOP__SILVERPOP_BEHAVIOR_SCORE__C,SILVERPOP__SILVERPOP_LEAD_RANK__C,SILVERPOP__SILVERPOP_LEAD_SCORE__C,SILVERPOP__SILVERPOP_RECIPIENTID__C,SILVERPOP__SYNC_TO_SILVERPOP_CHK__C,STYLE_SPECIFIC_STRATEGY_COVERAGE__C,SUB_ASSET_CLASS_COVERAGE__C,SUBSCRIPTIONSOPTOUT__C,TEAM_MEMBER_FLAG__C,TOT_CURRENT_AUM__C,TOT_PRIOR_YEAR1_AUM__C,TOT_PRIOR_YEAR1_REDS__C,TOT_PRIOR_YEAR1_SLS__C,TOT_PRIOR_YEAR2_REDS__C,TOT_PRIOR_YEAR2_SLS__C,TOT_R12_REDS__C,TOT_R12_SLS__C,TOT_YTD_REDS__C,TOT_YTD_SLS__C,USER_PAGE__C,SystemModstamp,Segment__C,COI_OWNER__C,COI_TYPE__C,FirstName,LastName,RETIREMENT_SPECIALIST__C,Client_Tier__c From Contact";
	  //String QUERY="Select ID,ACCOUNTID,isdeleted,AFFILIATE__C,SystemModstamp,CreatedDate From Contact where SystemModstamp<=2020-06-30T06:06:11.000Z OR CreatedDate<=2020-06-30T06:06:11.000Z";
	  // where SystemModstamp <=2020-06-30 OR CreatedDate <=2020-06-30 //2020-04-17T14:17:03.000+0000
	  //String QUERY="Select ID,ACCOUNTID,isdeleted,AFFILIATE__C,SystemModstamp,CreatedDate From Contact where SystemModstamp>=2017-06-30T06:06:11.000Z AND SystemModstamp<=2017-07-10T06:06:11.000Z";
	  public String QUERY="Select ID,ACCOUNTID,isdeleted,REGIONAL_DIRECTOR__C,STATUS__C,CHANNEL__C,CLIENT_SERVICE_MANAGER__C,COMPANY_REGION__C,CONTACT_CHANNEL_DERIVED__C,CONTACT_SALES_DIRECTOR__C,CONTACT_TYPE__C,CONTACT_ZONE__C,SystemModstamp,CreatedDate From Contact where (SystemModstamp>=#START_Date_Time# AND SystemModstamp<=#END_Date_Time#) OR (CreatedDate>=#START_Date_Time# AND CreatedDate<=#END_Date_Time#)";
	  //String QUERY="Select ID,ACCOUNTID,isdeleted,AFFILIATE__C,SystemModstamp,CreatedDate From Contact where (SystemModstamp>=2017-07-10T06:06:11.000Z AND SystemModstamp<=2017-07-30T06:06:11.000Z) OR (CreatedDate>=2017-07-10T06:06:11.000Z AND CreatedDate<=2017-07-30T06:06:11.000Z)";
	/**
	    * getConnection will take follwing values
	    * @param loginURL
	    * @param username
	    * @param password
	    * @return partner connection to connect to Salesforce
	    * @throws ConnectionException 
	    */
	  public PartnerConnection getConnection(String loginURL, String username, String password) throws URISyntaxException, ConnectionException  {
	      //log.debug("*****In Salesforce Query Handler getConnection method***")
	      ConnectorConfig config = new ConnectorConfig();
	      config.setUsername(username);
	      config.setPassword(password);
	      String authEndPoint = new URI(loginURL).toString();
	      config.setAuthEndpoint(authEndPoint);
	      config.setServiceEndpoint(authEndPoint);
	      PartnerConnection conn = Connector.newConnection(config);
	      return conn;
	  }
	  
	  /**
	    * getAccessToken will take connection as input and returns the sessionID which has to be passed as header Bearer token
	    * @return sessionId
	    */
	  public String  getAccesToken(PartnerConnection connection) {
	    return connection.getConfig().getSessionId();
	  }
	    
	  
	// getSalesForceURLDetails will take connection as input and return protocol and rest endpoint
	  /**
	    *
	    * @return
	 * @throws URISyntaxException 
	 * @throws MalformedURLException 
	    */
	  public Pair<String, String> getSalesForceURLDetails(PartnerConnection connection) throws URISyntaxException, MalformedURLException {
	    //log.debug("*****In Salesforce Query Handler getSalesForceURLDetails***")
			URL url = new URL(connection.getConfig().getServiceEndpoint());
			//(s"${url.getProtocol}://${url.getHost}", url.toURI.getPath.split("/")(4))
			System.out.println(String.format("%1$s://%2$s",url.getProtocol(),url.getHost()));
			System.out.println(url.toURI().getPath().split("/")[4]);
	    return new Pair<String, String>(String.format("%1$s://%2$s",url.getProtocol(),url.getHost()), url.toURI().getPath().split("/")[4]);
	  }
	    
	//getEncodedURL take query as input and returns a UTF-8 encoded query format which helps taking care of special symbols in the url
	  public String getEncodedURL(String queryString) throws UnsupportedEncodingException {
	    String encodedQuery = java.net.URLEncoder.encode(queryString, "UTF-8");
	    return encodedQuery;
	  }
	  
	//buildQueryURL will construct query based on the nextRecordsURL from Json or the Intial URL with query
	  public String  buildQueryURL(PartnerConnection connection,boolean isFirstRequest,String queryPath,String queryString, String INIT_URL) throws URISyntaxException, MalformedURLException {
		Pair<String,String> url_version=getSalesForceURLDetails(connection);
		String url = url_version.getValue0();
		String version = url_version.getValue1();
		return isFirstRequest?String.format("%1$s/%2$s%3$s", url, INIT_URL, queryString):String.format("%1$s%2$s", url, queryPath);
	  }
	  
	  public String nextURL(JSONObject jsonObj){
		    //log.debug("*****In Salesforce Query Handler nextURL***")
		 // JSONObject obj = new JSONObject(json);
		  if(jsonObj.has("nextRecordsUrl")) {
			 return  jsonObj.get("nextRecordsUrl").toString();
		  }
		  return null;
	  }	  
	  
	  
	  
	  
	  /* querySalesForce will take url and access_token as inputs and hit the http request to salesforce and returns response as json
	   */
	   public String querySalesForce(String url, String accesToken) throws ClientProtocolException, IOException {
	       //log.debug("*****In Salesforce Query Handler querySalesForce***")
	       HttpGet request = new HttpGet(url);
	       request.addHeader(HEADER_AUTH, HEADER_OAUTH + accesToken);
	       request.addHeader(HEADER_ACCEPT, CONTENT_TYPE_APPLICATION_JSON);
	       CloseableHttpClient client = HttpClientBuilder.create().build();
	       CloseableHttpResponse response = client.execute(request);
	       BasicResponseHandler handler = new BasicResponseHandler();
	       System.out.println("-----------");
	       String body = handler.handleResponse(response);
	      // System.out.println(body);
	       if(response.getStatusLine().getStatusCode() != 200) {
	    	   System.out.println(response.getStatusLine().getStatusCode());
	         throw new RuntimeException(body);
	       }
	       return body;
	     }
	  
	   public List<String> getQueryToHeaders(String queryStr) {
		   List<String> colList=new ArrayList<String>();
			    Pattern r = Pattern.compile("[s|S]elect(.*)[f|F]rom.*");
			    Matcher m = r.matcher(queryStr);
			    if (m.find()) {
			    	colList.addAll(Arrays.asList(m.group(0).split(",")));
			    }
			    return colList;
			  }
	   
	/*public static void main(String[] args) throws Exception {
		Boolean isDeletedRecord=Boolean.TRUE;
		String version="v39.0";
		String INIT_URL = isDeletedRecord? String.format("services/data/%1$s/queryAll/?q=",version) : String.format("services/data/%1$s/query/?q=",version);
		SalesForceExtract salesForceExtract = new SalesForceExtract();
		PartnerConnection connection = salesForceExtract.getConnection("https://test.salesforce.com/services/Soap/u/39.0","edmsfdc@leggmason.com.uat",DecryptUtil.decryptCode("RHVrZSRIYSQkYXJkUHJlbWllcmUxOTc1IWZBd0daSFhQSmw0TVZwNGZlbkpEd3FPdXU="));
		String accessToken=salesForceExtract.getAccesToken(connection);
		System.out.println(accessToken);
		salesForceExtract.getQueryToHeaders(salesForceExtract.QUERY.replaceAll("#START_Date_Time#", "2020-07-08T06:06:11.000Z").replaceAll("#END_Date_Time#", "2020-07-10T06:06:11.000Z"));
		String queryString = salesForceExtract.getEncodedURL(salesForceExtract.QUERY.replaceAll("#START_Date_Time#", "2020-04-08T06:06:11.000Z").replaceAll("#END_Date_Time#", "2020-07-10T06:06:11.000Z"));
		System.out.println(queryString);
		String firstRequest=salesForceExtract.buildQueryURL(connection,true,"",queryString,INIT_URL);
		String data = salesForceExtract.querySalesForce(firstRequest,accessToken);
		JSONObject json = new JSONObject(data);//JSONArray jArray = (JSONArray)
		
		Consumer<Object> printConsumer = new Consumer<Object>() {
		    public void accept(Object object) {
		    	Map<String, Object> row = (Map)object;
		    	System.out.println(row.toString());
		    };
		};
		 (((JSONArray)json.getJSONArray("records")).toList()).forEach(printConsumer);
		 while(null != salesForceExtract.nextURL(json)) {
			 queryString = salesForceExtract.buildQueryURL(connection,false,salesForceExtract.nextURL(json),"",null);
			 data = salesForceExtract.querySalesForce(queryString, accessToken);
			 System.out.println("coming-next"+data);
			 json = new JSONObject(data);
		 }
		 
	}*/


}
