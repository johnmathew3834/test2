package org.leggmason.edm.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.leggmason.edm.utils.security.DecryptUtil;

public class DBService {

	public String getOrUpdateData(boolean isUpdate, String datetime) {
		String	returnStr="";
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://lm-edm-medata-ndev.cvhxtkvmskel.us-east-1.rds.amazonaws.com:5432/lmedmmetadatadev?sslmode=require&sslfactory=org.postgresql.ssl.NonValidatingFactory", "edm_app_user",
				DecryptUtil.decryptCode("dGVzdEVETTEyMw=="))) {

			System.out.println("Java JDBC PostgreSQL Example");
			// When this class first attempts to establish a connection, it automatically
			// loads any JDBC 4.0 drivers found within
			// the class path. Note that your application must manually load any JDBC
			// drivers prior to version 4.0.
			// Class.forName("org.postgresql.Driver");

			System.out.println("Connected to PostgreSQL database!");
			Statement statement = connection.createStatement();
			if(isUpdate) {
				statement.executeUpdate("update edm_metadata.kinesis_time_capture set last_accessed_time='"+datetime+"' where id=102");
			} else {
			System.out.println("Reading kinesis_time_capture records...");
			//System.out.printf("%-30.30s  %-30.30s%n", "Model", "Price");
			ResultSet resultSet = statement.executeQuery("SELECT last_accessed_time FROM edm_metadata.kinesis_time_capture where id=102");
			/*while (resultSet.next()) {
				System.out.printf("%-30.30s  %-30.30s%n", resultSet.getString("batch_id"), resultSet.getString("id"));
			}*/
			if(resultSet.next()) {
				returnStr=resultSet.getString("last_accessed_time");
			}
			}

		} /*
			 * catch (ClassNotFoundException e) {
			 * System.out.println("PostgreSQL JDBC driver not found."); e.printStackTrace();
			 * }
			 */ catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return returnStr;
	}
public static void main(String[] args) {
	DBService service = new DBService();
	service.getOrUpdateData(false,"");
	DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	DateTime dateTime = DateTime.parse("2017-07-10T06:06:11.000Z",dateTimeFormatter);
	dateTime = dateTime.plusDays(10);
	System.out.println(dateTime.toString(dateTimeFormatter));
}
}