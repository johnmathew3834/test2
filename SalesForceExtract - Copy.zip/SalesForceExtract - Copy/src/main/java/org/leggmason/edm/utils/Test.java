package org.leggmason.edm.utils;

import org.joda.time.DateTime;
import org.joda.time.DateTimeComparator;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class Test {
	public static void main(String[] args) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		DateTime dateTime = DateTime.parse("2018-01-11T06:06:11.000Z",dateTimeFormatter);
		System.out.println(DateTimeComparator.getInstance().compare(dateTime, new DateTime()));
		
		System.out.println(400%400);
	}

}
