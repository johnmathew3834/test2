package org.leggmason.gd.edm.cdc

import com.leggmason.gd.edm.service.CDCProperties
import org.apache.spark.sql.SparkSession


/**
  * Created by himanshu on 9/10/2017.
  */
class PerformCDCProduct(cdcProperties: CDCProperties, spark: SparkSession) extends PerformCDC(cdcProperties, spark) {

  override def createDataFrames: Unit = {

  }

}
