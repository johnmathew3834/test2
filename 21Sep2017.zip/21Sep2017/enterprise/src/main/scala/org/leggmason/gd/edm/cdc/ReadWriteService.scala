package org.leggmason.gd.edm.cdc

import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.commons.lang3.StringUtils

/**
  * Created by himanshu on 6/4/2017.
  */

@SerialVersionUID(100L)
class ReadWriteService
  extends java.io.Serializable
{

  /*def readAndGetDF() : DataFrame = {
    // create the schema from a string, splitting by delimiter
    val headerSchema = StructType(headerString.split(delimiter).map(fieldName => StructField(fieldName, StringType, true)))

    //create input RDD
    val inputRDD = spark.sparkContext.textFile(fileLocation).map(row => row.split(delimiter,-1))
      .map(a => Row.fromSeq(a))

    return spark.sqlContext.createDataFrame(inputRDD , headerSchema)

  }*/
  
  def readAsDF(spark: SparkSession, sourceFileLocationtion: String, headerString: String, fileFormat: String, delimiter: String): DataFrame = {
    // create the schema from a string, splitting by delimiter
    val schema = StructType(headerString.split(",").map(fieldName => StructField(fieldName, StringType, true)))
   
    StringUtils.upperCase(fileFormat) match {
      case "TEXT" => {
        if(StringUtils.equals(delimiter,"\t")){
          return spark.read.schema(schema).text(sourceFileLocationtion)
        } else {
          return spark.read.schema(schema).option("delimiter", delimiter).csv(sourceFileLocationtion);
        }
        
      }
      case "CSV"  => return spark.read.schema(schema).csv(sourceFileLocationtion);
      case "PARQUET" => return spark.read.parquet(sourceFileLocationtion);
    }
    return null
  }
  
  def write(df: DataFrame, location: String, format: String): Unit = {
    StringUtils.upperCase(format) match {
      case "PARQUET" => df.write.parquet(location)
      case "CSV" => df.write.csv(location)
      case "TEXT" => df.write.text(location)
    }
  }

}
