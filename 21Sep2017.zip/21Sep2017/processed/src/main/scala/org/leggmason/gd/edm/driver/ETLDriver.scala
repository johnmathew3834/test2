package org.leggmason.gd.edm.driver

import com.leggmason.gd.edm.service.{CommandLineArgs, ObjectSchemaCreator}
import org.apache.spark.sql._
import org.leggmason.gd.edm.driver.etl.RawToProcessedETL


/**
  * Created by himanshu on 8/5/2017.
  */
object ETLDriver {

  def main(args: Array[String]): Unit = {

    //Verify command line arguments
    val commandLineArgs = new CommandLineArgs(args)

    // TODO - Call Rest API code to get current date for which job needs to run and check if all dependencies are met
    // TODO - Rest API code should return a boolean true or false
    // TODO - Rest API code should return a JSON file with date and target execution ID
    // TODO - Pass date to the run method below along with command line arguments

    //Get Spark Session
    //TODO - Get Job Name from properties file
    val spark = SparkSession.builder().appName("RawToProcessedETL").master("local").getOrCreate()

    //Read Source JSON File and convert it into an object
    val objectSchema = ObjectSchemaCreator.getObjectSchema(commandLineArgs.getMetaFileLocation)

    //Create instance of ETL
    val rawToProcessedETL = new RawToProcessedETL(spark, objectSchema)

    //Run the ETL Process
    rawToProcessedETL.run(commandLineArgs)

  }


}
