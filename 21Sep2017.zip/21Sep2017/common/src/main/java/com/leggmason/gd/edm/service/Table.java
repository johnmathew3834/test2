package com.leggmason.gd.edm.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tableName",
        "headerString",
        "location",
        "fileFormat",
        "delimiter",
        "fileType"
})
public class Table implements Serializable {

    @JsonProperty("tableName")
    private String tableName;
    
    @JsonProperty("headerString")
    private String headerString;
    
    @JsonProperty("location")
    private String location;
    
    @JsonProperty("fileFormat")
	private String fileFormat;

	@JsonProperty("delimiter")
	private String delimiter;

	@JsonProperty("fileType")
	private String fileType;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getHeaderString() {
        return headerString;
    }

    public void setHeaderString(String headerString) {
        this.headerString = headerString;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

}
