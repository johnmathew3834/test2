package com.leggmason.gd.edm.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

/**
 * Created by himanshu on 6/4/2017.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "jobName", 
					"jobDescription", 
					"table", 
					"newInsertsQuery", 
					"updatedRecordsInsertsQuery",
					"updatedRecordsUpdatesQuery", 
					"unchangedRecordsQuery", 					
					"maxKeyQuery",
					"firstTimeRecordInsert",
					"targetHeaderColumns",					 					 
					"destinationFileFormat" })
public class CDCProperties {

    private static CDCProperties cdcProperties;

    private CDCProperties() {
    }
    
    @JsonProperty("jobName")
    private String jobName;
    
    @JsonProperty("jobDescription")
    private String jobDescription;
    
    @JsonProperty("table")
    private Table[] table;
    
    @JsonProperty("newInsertsQuery")
    private String newInsertsQuery;

    @JsonProperty("updatedRecordsInsertsQuery")
    private String updatedRecordsInsertsQuery;
    
    @JsonProperty("updatedRecordsUpdatesQuery")
    private String updatedRecordsUpdatesQuery;	
    
    @JsonProperty("unchangedRecordsQuery")
    private String unchangedRecordsQuery;

    @JsonProperty("targetHeaderColumns")
    private String targetHeaderColumns;
    
    @JsonProperty("maxKeyQuery")
    private String maxKeyQuery;
    
    @JsonProperty("firstTimeRecordInsertQuery")
    private String firstTimeRecordInsertQuery;
    
    @JsonProperty("destinationFileFormat")
    private String destinationFileFormat;
    
    private boolean runFirstTime;

    public static CDCProperties getCdcProperties() {
        return cdcProperties;
    }

    public static void setCdcProperties(CDCProperties cdcProperties) {
        CDCProperties.cdcProperties = cdcProperties;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public Table[] getTable() {
        return table;
    }

    public void setTable(Table[] table) {
        this.table = table;
    }

    public String getNewInsertsQuery() {
        return newInsertsQuery;
    }

    public void setNewInsertsQuery(String newInsertsQuery) {
        this.newInsertsQuery = newInsertsQuery;
    }

    public String getUpdatedRecordsInsertsQuery() {
        return updatedRecordsInsertsQuery;
    }

    public void setUpdatedRecordsInsertsQuery(String updatedRecordsInsertsQuery) {
        this.updatedRecordsInsertsQuery = updatedRecordsInsertsQuery;
    }

    public String getUpdatedRecordsUpdatesQuery() {
        return updatedRecordsUpdatesQuery;
    }

    public void setUpdatedRecordsUpdatesQuery(String updatedRecordsUpdatesQuery) {
        this.updatedRecordsUpdatesQuery = updatedRecordsUpdatesQuery;
    }

    public String getUnchangedRecordsQuery() {
        return unchangedRecordsQuery;
    }

    public void setUnchangedRecordsQuery(String unchangedRecordsQuery) {
        this.unchangedRecordsQuery = unchangedRecordsQuery;
    }

    public String getTargetHeaderColumns() {
        return targetHeaderColumns;
    }

    public void setTargetHeaderColumns(String targetHeaderColumns) {
        this.targetHeaderColumns = targetHeaderColumns;
    }

    public String getMaxKeyQuery() {
        return maxKeyQuery;
    }

    public void setMaxKeyQuery(String maxKeyQuery) {
        this.maxKeyQuery = maxKeyQuery;
    }
    
    public String getFirstTimeRecordInsertQuery() {
		return firstTimeRecordInsertQuery;
	}

	public void setFirstTimeRecordInsertQuery(String firstTimeRecordInsertQuery) {
		this.firstTimeRecordInsertQuery = firstTimeRecordInsertQuery;
	}

	public String getDestinationFileFormat() {
		return destinationFileFormat;
	}

	public void setDestinationFileFormat(String destinationFileFormat) {
		this.destinationFileFormat = destinationFileFormat;
	}

    public static CDCProperties getCDCProperties(String jsonFileLocation) throws IOException {

        if (cdcProperties == null) {
            ObjectMapper mapper = new ObjectMapper();
            cdcProperties = mapper.readValue(new File(jsonFileLocation), CDCProperties.class);
        }

        return cdcProperties;
    }

	public boolean isRunFirstTime() {
		return runFirstTime;
	}

	public void setRunFirstTime(boolean runFirstTime) {
		this.runFirstTime = runFirstTime;
	}
	
}
