package com.coe.data.process

import java.nio.ByteBuffer
import scala.collection.mutable.Map

import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider
import com.amazonaws.regions.RegionUtils
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream
import com.amazonaws.services.kinesis.model.{PutRecordsRequest, PutRecordsRequestEntry, PutRecordsResult}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession, DataFrame}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.kinesis.KinesisUtils
import org.apache.spark.streaming.{Seconds, StreamingContext, Time}
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.sql.SQLContext;

import com.coe.stream.util.HttpClientUtil;
import com.coe.stream.util.CommonUtils

case class HashTag(hashtag:String, hashtag_count:Int)
  
object TwitterDriver extends Serializable{
  var url:String=null
  def main(args: Array[String]): Unit = {
    val spark = new SparkSession.Builder().appName("TwitterTrendingHashCount").getOrCreate()
    val streamName:String="twitter_data"
    val clientBuilder = AmazonKinesisClientBuilder.standard
    clientBuilder.setRegion("us-east-1")
    val kinesisClient = clientBuilder.build
    kinesisClient.describeStream(streamName)
    kinesisClient.describeStream(streamName).getStreamDescription()

    val numShards = kinesisClient.describeStream(streamName).getStreamDescription().getShards().size
     println("ooooooo  :: "+numShards)
    println("Region Name : "+RegionUtils.getRegionMetadata.getRegionByEndpoint("kinesis.us-east-1.amazonaws.com")
      .getName())
    val propMap:scala.collection.mutable.Map[String,String]=CommonUtils.loadPropertyFile("common_process.properties")
    println(propMap("url"))
    url=propMap("url");
    CommonUtils.loadPropertyFile("common_process.properties")
    var paramMap = Map[String, String]();
    val sc = spark.sparkContext
    val batchInterval = Seconds(1)
    val kinesisCheckpointInterval = batchInterval
    val ssc = new StreamingContext(sc, Seconds(1))
    ssc.checkpoint("s3://aws-coe/checkpoint")
    val numStreams = numShards
    val kinesisStreams = (0 until numStreams).map { i =>
      val kinesisStream = KinesisUtils.createStream(
        ssc,
        "newapp",
        "twitter_data",
        "kinesis.us-east-1.amazonaws.com",
        RegionUtils.getRegionMetadata.getRegionByEndpoint("kinesis.us-east-1.amazonaws.com")
          .getName(),
        InitialPositionInStream.TRIM_HORIZON,
        batchInterval,
        StorageLevel.MEMORY_AND_DISK_SER_2)
      kinesisStream
    }
      // Union all the streams (in case numStreams > 1)
    val unionStreams:DStream[Array[Byte]] = ssc.union(kinesisStreams)
    val words = unionStreams.flatMap(byteArray => new String(byteArray).split(" "))
    val hashtags=words.map{word => (word, 1)}/*.reduceByKey(_ + _)*/
    
    
    //adding the count of each hashtag to its last count
    val tags_totals = hashtags.updateStateByKey(new Aggarations().aggregateTagsCount)
    // do processing for each RDD generated in each interval
    tags_totals.foreachRDD(processRdd _)
    ssc.start()
    ssc.awaitTermination()
  }
  
  /*def aggregateTagsCount(newValues: Seq[(Int)], runningCount: Option[(Int)]): Option[(Int)]={
    var result: Option[(Int)] = null
          if(newValues.isEmpty){ //check if the key is present in new batch if not then return the old values
          result=Some(runningCount.get)
          }
          else{
          newValues.foreach { x => {// if we have keys in new batch ,iterate over them and add it
          if(runningCount.isEmpty){
          result=Some(x)// if no previous value return the new one
          }else{
          result=Some(x+runningCount.get) // update and return the value
          }
          } }
          }
    result
  }*/
  
  def processRdd(rdd: RDD[(String,Int)], time: Time){    
    val rowRdd=rdd.map(x=>HashTag(x._1,x._2))
    val sqlContext = new SQLContext(rdd.sparkContext)
    import sqlContext.implicits._
    rowRdd.toDF().createOrReplaceTempView("hashtags")
    val hashtagCountsDF =sqlContext.sql("select hashtag, hashtag_count from hashtags order by hashtag_count desc limit 10");
    hashtagCountsDF.show()
    send_df_to_dashboard(hashtagCountsDF)
  }
  
  
  def send_df_to_dashboard(df:DataFrame){
    // extract the hashtags from dataframe and convert them into String
    val topTags:String=df.select("hashtag").collect().map(_.toSeq).mkString("['","','","']");
    //extract the counts from dataframe and convert them into String
    val tagsCount:String=df.select("hashtag_count").collect().map(_.toSeq).mkString("[",",","]");
    
    df.show
  
  //initialize and send the data through REST API
	//val url = 'http://localhost:5001/updateData'
	//Map("label"->Array("'TamilNaduuu'","'Karnataka'","'Andra'","'Telengana'","'Kerala'","'Maharastra'","'Madhya Pradresh'","'Sikkim'","'Goa'","'Delhi'").mkString("[", ",", "]"),"data"->Array(10002,10,234,8000,6500,400,40,10,6000,200).mkString("[", ",", "]"))
	//val request_data = {'label': str(top_tags), 'data': str(tags_count)}
	val params = scala.collection.immutable.Map("label" -> topTags,"data" -> tagsCount)
	println("Urllll ------> "+url)
	HttpClientUtil.postContent(url=url, 
	    connectionTimeout=30, 
	    socketTimeout=30, 
	    params=params)
	//requests.post(url, data=request_data)
  }
}