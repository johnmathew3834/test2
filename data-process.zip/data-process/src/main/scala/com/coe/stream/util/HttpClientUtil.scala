package com.coe.stream.util

import java.io._
import org.apache.http.{HttpEntity, HttpResponse}
import org.apache.http.client._
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.DefaultHttpClient
import scala.collection.mutable.StringBuilder
import org.apache.http.client.entity.UrlEncodedFormEntity;
import scala.xml.XML
import org.apache.http.params.HttpConnectionParams
import org.apache.http.params.HttpParams
import org.apache.http.client.methods.HttpPost
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import java.util.ArrayList
import org.apache.http.impl.client.HttpClients
import org.apache.http.impl.client.CloseableHttpClient

object HttpClientUtil {
  /**
  * Returns the text (content) from a REST URL as a String.
  * Returns a blank String if there was a problem.
  * This function will also throw exceptions if there are problems trying
  * to connect to the url.
  *
  * @param url A complete URL, such as "http://foo.com/bar"
  * @param connectionTimeout The connection timeout, in ms.
  * @param socketTimeout The socket timeout, in ms.
  */
def getRestContent(url: String,
                   connectionTimeout: Int,
                   socketTimeout: Int): String = {
    val httpClient = buildHttpClient(connectionTimeout, socketTimeout)
    val httpResponse = httpClient.execute(new HttpGet(url))
    val entity = httpResponse.getEntity
    var content = ""
    /*if (entity != null) {
        val inputStream = entity.getContent
        content = io.Source.fromInputStream(inputStream).getLines.mkString
        inputStream.close
    }*/
    httpClient.getConnectionManager.shutdown
    content
}

def postContent(url: String,
                   connectionTimeout: Int,
                   socketTimeout: Int, params:Map[String, String]){
   val httpClient = buildHttpClient(connectionTimeout, socketTimeout)
   val post:HttpPost = new HttpPost(url);
   val nameValuePairs = new ArrayList[NameValuePair]()
   params foreach {
     case (k,v)=>
       println(k+" --> "+v)
       nameValuePairs.add(new BasicNameValuePair(k, v));
   }
   print(nameValuePairs)
   post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
   val response = httpClient.execute(post)
   println("--- HEADERS ---")
   response.getAllHeaders.foreach(arg => println(arg))
   println(response.getStatusLine())
}

private def buildHttpClient(connectionTimeout: Int, socketTimeout: Int):
CloseableHttpClient = {
    val httpClient = HttpClients.createDefault()
    httpClient
}

def main(args: Array[String]): Unit = {
  
  postContent("http://ec2-54-87-192-58.compute-1.amazonaws.com/updateData",300,300,Map("label"->Array("'TamilNaduuu'","'Karnataka'","'Andra'","'Telengana'","'Kerala'","'Maharastra'","'Madhya Pradresh'","'Sikkim'","'Goa'","'Delhi'").mkString("[", ",", "]"),"data"->Array(10002,10,234,8000,6500,400,40,10,6000,200).mkString("[", ",", "]")))
}
}