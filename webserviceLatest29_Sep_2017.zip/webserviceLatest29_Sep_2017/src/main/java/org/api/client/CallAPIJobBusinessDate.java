package org.api.client;

import java.util.HashMap;
import java.util.Map;

import org.apigateway.generic.GenericApiGatewayClient;
import org.apigateway.generic.GenericApiGatewayException;
import org.apigateway.generic.GenericApiGatewayRequestBuilder;
import org.apigateway.generic.GenericApiGatewayResponse;
import org.apigateway.util.APIHelper;

import com.amazonaws.http.HttpMethodName;

public class CallAPIJobBusinessDate {

	/*
	 * This method will fetch business date for job execution from API.
	 */
	public static String getBusinessDate(StringBuilder param) {

		GenericApiGatewayClient client = APIHelper.getApiGatewayClient("jobbusinessdate");

		Map<String, String> header = new HashMap<String, String>();
		header.put("Content-Type", "application/json");

		GenericApiGatewayResponse response = null;

		try {
			response = client.execute(new GenericApiGatewayRequestBuilder().withHttpMethod(HttpMethodName.GET)
					.withHeaders(header).withResourcePath("/" + param).build());

			System.out.println("Response : " + response.getBody());
			String output = response.getBody().replaceAll("\\\\\"", "\"");
			output = output.substring(2, output.length() - 3);
			String[] date = output.split("\\: ");
			return date[1].replace(" ", "T").replaceAll("\"", "").trim();

		} catch (GenericApiGatewayException e) {
			System.out.println(String.format("Client threw exception with message %s and status code %s",
					e.getMessage(), e.getStatusCode()));
		}

		return null;
	}

}
