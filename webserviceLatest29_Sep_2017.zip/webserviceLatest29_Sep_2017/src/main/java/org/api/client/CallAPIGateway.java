package org.api.client;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CallAPIGateway {

	/*
	 * This method should be called to perform pre execution checks before job
	 * execution
	 */
	public static boolean callPreExecutionSteps(String job_id, String jobExecutionDate) {

		System.out.println("Execution date for JobId: " + job_id + " is : " + jobExecutionDate);

		// checking for last execution status
		CallAPIJobControl.checkLastExecutionStatus(
				new StringBuilder("?job_id=").append(job_id).append("&run_date=").append(jobExecutionDate));

		// Checking job dependencies
		System.out.println("Checking job dependencies for JobId: " + job_id);
		String response = CallAPIJobDependency.checkStatusforJobDependencies(
				new StringBuilder("?job_id=").append(job_id).append("&run_date=").append(jobExecutionDate));

		if (response.contains("DEPENDENCY_MET")) {
			// update job status to STARTED in control table
			System.out.println(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date()));
			if (callPostExecutionSteps(new StringBuilder("?start_date_time=")
					.append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date())).append("&job_id=")
					.append(job_id).append("&run_date=").append(jobExecutionDate).append("&stage=STARTED")))

				System.out.println("Status updated to STARTED for JobId: " + job_id);

			else {
				System.out.println("status could not be updated for JobId: " + job_id);
				return false;
			}
			return true;

		} else {
			System.out.println("job dependencies are not in proper state,can not continue...");
			return false;
		}

	}

	/*
	 * This method should be called after job execution to update the status in
	 * table : DWH_ETL_JOB_INSTANCE.
	 */
	public static boolean callPostExecutionSteps(StringBuilder param) {

		String response1 = CallAPIJobControl.updateJobStatus(param);
		if (response1.contains("Update_Successful"))
			return true;
		else
			return false;

	}

}
