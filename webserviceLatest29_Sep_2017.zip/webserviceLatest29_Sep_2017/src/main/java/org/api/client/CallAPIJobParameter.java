package org.api.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apigateway.generic.GenericApiGatewayClient;
import org.apigateway.generic.GenericApiGatewayException;
import org.apigateway.generic.GenericApiGatewayRequestBuilder;
import org.apigateway.generic.GenericApiGatewayResponse;
import org.apigateway.util.APIHelper;

import com.amazonaws.http.HttpMethodName;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CallAPIJobParameter {

	public static String getParameters(StringBuilder param) {

		GenericApiGatewayClient client = APIHelper.getApiGatewayClient("jobparameter");

		Map<String, String> header = new HashMap<>();
		header.put("Content-Type", "application/json");

		GenericApiGatewayResponse response = null;

		try {
			response = client.execute(new GenericApiGatewayRequestBuilder().withHttpMethod(HttpMethodName.GET)
					.withHeaders(header).withResourcePath("/" + param).build());

			System.out.println("Response : " + response.getBody());

		} catch (GenericApiGatewayException e) {
			System.out.println(String.format("Client therw exception with message %s and status code %s",
					e.getMessage(), e.getStatusCode()));
		}
		String output = response.getBody().replaceAll("\\\\\"", "\"");
		output = output.substring(2, output.length() - 2);
		System.out.println(output);
		return output;

	}

	public static List<String> parseJsonParams(StringBuilder param) {
		try {
			JsonFactory f = new JsonFactory();
			JsonParser jp = f.createParser(getParameters(param));
			ObjectMapper mapper = new ObjectMapper();
			AwsJsonMapper E = mapper.readValue(jp, AwsJsonMapper.class);
			List<String> paramValues = new ArrayList<String>();
			paramValues.add(E.getOutputPath());
			paramValues.add(E.getInputPath());

			return paramValues;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static class AwsJsonMapper {

		@JsonProperty("outputfiles")
		public String outputPath;
		@JsonProperty("inputfiles")
		public String inputPath;

		@JsonCreator
		public AwsJsonMapper(@JsonProperty("output") String outputPath, @JsonProperty("schema") String schemaFile,
				@JsonProperty("input1") String input1, @JsonProperty("input") String inputPath) {
			this.outputPath = outputPath;
			this.inputPath = inputPath;
		}

		public String getOutputPath() {
			return outputPath;
		}

		public void setOutputPath(String outputPath) {
			this.outputPath = outputPath;
		}

		public String getInputPath() {
			return inputPath;
		}

		public void setInputPath(String inputPath) {
			this.inputPath = inputPath;
		}

	}

}
