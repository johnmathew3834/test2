package org.api.client;

import java.util.HashMap;
import java.util.Map;

import org.apigateway.generic.GenericApiGatewayClient;
import org.apigateway.generic.GenericApiGatewayException;
import org.apigateway.generic.GenericApiGatewayRequestBuilder;
import org.apigateway.generic.GenericApiGatewayResponse;
import org.apigateway.util.APIHelper;

import com.amazonaws.http.HttpMethodName;

public class CallAPIJobControl {

	// select
	public static String selectRecords(StringBuilder param) {

		GenericApiGatewayClient client = APIHelper.getApiGatewayClient("jobcontrol");

		Map<String, String> header = new HashMap<String, String>();
		header.put("Content-Type", "application/json");

		GenericApiGatewayResponse response = null;

		try {
			response = client.execute(new GenericApiGatewayRequestBuilder().withHttpMethod(HttpMethodName.GET)
					.withHeaders(header).withResourcePath("/" + param).build());

			System.out.println("Response : " + response.getBody());

		} catch (GenericApiGatewayException e) {
			System.out.println(String.format("Client threw exception with message %s and status code %s",
					e.getMessage(), e.getStatusCode()));
		}
		return response.getBody().toString();
	}

	/*
	 * This method will update job status in job control table.
	 */
	public static String updateJobStatus(StringBuilder param) {

		GenericApiGatewayClient client = APIHelper.getApiGatewayClient("jobcontrol");

		Map<String, String> header = new HashMap<String, String>();
		header.put("Content-Type", "application/json");

		GenericApiGatewayResponse response = null;

		try {
			response = client.execute(new GenericApiGatewayRequestBuilder().withHttpMethod(HttpMethodName.PUT)
					.withHeaders(header).withResourcePath("/" + param).build());

			System.out.println("Response : " + response.getBody());
		} catch (GenericApiGatewayException e) {
			System.out.println(String.format("Client threw exception with message %s and status code %s",
					e.getMessage(), e.getStatusCode()));
		}
		return response.getBody().toString();
	}

	/*
	 * This method will check for the last execution status for the job. API
	 * will insert new record in table if last execution status is failed.
	 */
	public static String checkLastExecutionStatus(StringBuilder param) {

		GenericApiGatewayClient client = APIHelper.getApiGatewayClient("jobcontrol");

		Map<String, String> header = new HashMap<String, String>();
		header.put("Content-Type", "application/json");

		GenericApiGatewayResponse response = null;

		try {
			System.out.println("param :" + param);
			response = client.execute(new GenericApiGatewayRequestBuilder().withHttpMethod(HttpMethodName.POST)
					.withHeaders(header).withResourcePath("/" + param).build());

			System.out.println("Response : " + response.getBody());
		} catch (GenericApiGatewayException e) {
			System.out.println(String.format("Client threw exception with message %s and status code %s",
					e.getMessage(), e.getStatusCode()));
		}
		return response.getBody().toString();
	}

}
