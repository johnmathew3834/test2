package org.apigateway.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UtilityFunctions {

	/*
	 * This function will check for business execution date for the provided job
	 * id.
	 */
	public static String getJobExecutionTime(String jobId, String fileName) {
		StringBuilder sb = new StringBuilder();
		File fileToRead = new File(fileName);
		Scanner scanner = null;
		try {
			scanner = new Scanner(fileToRead);
		} catch (FileNotFoundException e) {
			System.out.println(fileName + " file not found !!");
			System.out.println("Error Message - " + e.getMessage());
		}
		int noofLine = 0;
		while (scanner.hasNextLine()) {
			final String lineFromFile = scanner.nextLine();
			noofLine++;
			if (lineFromFile.trim().contains("JobId" + jobId + "==")) {
				System.out.println(
						"JobId:" + jobId + " found in file " + fileToRead.getName() + ". At line no - " + noofLine);
				sb.append(lineFromFile);
				break;
			}
			// else {
			// System.out.println("JobId:" + jobId + " not found in file " +
			// fileToRead.getName());
			// return null;
			// }
		}
		String jobTime = "";
		try {
			System.out.println(sb);
			if (sb.toString().indexOf("=") != sb.toString().lastIndexOf("=")) {
				jobTime = sb.toString().split("==")[1];
			} else if (sb.toString().indexOf("=") > 0) {
				jobTime = sb.toString().split("=")[1];
			}
		} catch (IndexOutOfBoundsException iob) {
			System.out.println("File values are not in expected format. eg. $$JOBID==2017-09-29");
		}

		return jobTime;
	}

	public static void writeResponseToFile(String json) {
		try {
			JsonFactory f = new JsonFactory();
			JsonParser jp = f.createParser(json);
			jp.nextToken();
			ObjectMapper mapper = new ObjectMapper();
			List<awsJsonMapper> e = new ArrayList<awsJsonMapper>();
			while (jp.nextToken() == JsonToken.START_OBJECT) {
				e.add(mapper.readValue(jp, awsJsonMapper.class));
			}
			writeEJBFile("D:\\API_OUTPUT\\out" + GregorianCalendar.getInstance().getTimeInMillis() + ".txt", e);
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	void readEJBFile(String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)) {
			@SuppressWarnings("unused")
			String line = null;
			while ((line = reader.readLine()) != null) {
			}
		}
	}

	final static Charset ENCODING = StandardCharsets.UTF_8;

	static void writeEJBFile(String aFileName, List<awsJsonMapper> aLines) throws IOException, ParseException {
		Path path = Paths.get(aFileName);
		try (BufferedWriter writer = Files.newBufferedWriter(path, ENCODING)) {
			for (awsJsonMapper line : aLines) {
				writer.write(line.getPrintableData());
				writer.newLine();
			}
		}
	}

	public static class awsJsonMapper {
		@JsonProperty("JobId")
		public String id;
		@JsonProperty("date")
		public String date;

		@JsonCreator
		public awsJsonMapper(@JsonProperty("JobId") String id, @JsonProperty("date") String date) {
			this.id = id;
			this.date = date;
		}

		public String getStatus() {
			return "$$id==" + id;
		}

		public String getDate() {
			return "$$startDate==" + date;
		}

		public String getPrintableData() throws ParseException {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			return "$$JobId" + id + "==" + format.format(format.parse(date));
		}

	}
}
