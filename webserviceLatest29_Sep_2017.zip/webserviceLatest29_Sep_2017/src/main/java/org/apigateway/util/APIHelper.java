package org.apigateway.util;

import org.apigateway.generic.GenericApiGatewayClient;
import org.apigateway.generic.GenericApiGatewayClientBuilder;
import org.apigateway.util.Constants;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;

public class APIHelper {

	public static AWSCredentialsProvider getCredentialProvider() {
		return new AWSCredentialsProvider() {
			public AWSCredentials getCredentials() {
				return new BasicAWSCredentials(Constants.AWS_ACCESS_KEY, Constants.AWS_SECRET_KEY);
			}

			public void refresh() {

			}
		};
	}

	public static GenericApiGatewayClient getApiGatewayClient(String function) {
		return new GenericApiGatewayClientBuilder().withClientConfiguration(new ClientConfiguration())
				.withCredentials(getCredentialProvider()).withEndpoint(Constants.API_ENDPOINT + function)
				.withRegion(com.amazonaws.regions.Region.getRegion((Regions.fromName(Constants.AWS_REGION))))
				.withApiKey(Constants.API_KEY).build();
	}

}
