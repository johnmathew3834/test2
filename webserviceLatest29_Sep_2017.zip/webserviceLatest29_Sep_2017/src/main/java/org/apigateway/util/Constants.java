package org.apigateway.util;

public class Constants {

	public static final String AWS_ACCESS_KEY = "AKIAI6PHGUVBDF4DUUTA";
	public static final String AWS_SECRET_KEY = "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";
	
	//mysql API
	//public static final String API_ENDPOINT = "https://1f6pl5fep0.execute-api.us-east-1.amazonaws.com/test/restapi/v1/";
	
	//postGres API
	public static final String API_ENDPOINT ="https://4winy8f55j.execute-api.us-east-1.amazonaws.com/Dev/restapi/v1/" ; 

	
	public static final String AWS_REGION = "us-east-1";
	public static final String API_KEY = "4k4rGX5X1P6PG8ADm90b3aJENaVF8J8l6G0tHV2T";

}
