package org.apigateway.util;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AwsJsonMapper implements Serializable {

	@JsonProperty("output")
	public String outputPath;
	@JsonProperty("schema")
	public String schemaFile;
	@JsonProperty("input1")
	public String input1;
	@JsonProperty("input")
	public String inputPath;

	@JsonCreator
	public AwsJsonMapper(@JsonProperty("output") String outputPath, @JsonProperty("schema") String schemaFile,
			@JsonProperty("input1") String input1, @JsonProperty("input") String inputPath) {
		this.outputPath = outputPath;
		this.schemaFile = schemaFile;
		this.input1 = input1;
		this.inputPath = inputPath;
	}

	public String getOutputPath() {
		return outputPath;
	}

	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

	public String getSchemaFile() {
		return schemaFile;
	}

	public void setSchemaFile(String schemaFile) {
		this.schemaFile = schemaFile;
	}

	public String getInput1() {
		return input1;
	}

	public void setInput1(String input1) {
		this.input1 = input1;
	}

	public String getInputPath() {
		return inputPath;
	}

	public void setInputPath(String inputPath) {
		this.inputPath = inputPath;
	}

}
