package com.leggmason.edm.edw.helper;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by himanshu on 6/4/2017.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "jobName", 
					"jobDescription", 
					"table", 
					"newInsertsQuery", 
					"updatedRecordsInsertsQuery",
					"updatedRecordsUpdatesQuery", 
					"unchangedRecordsQuery", 
					"firstTimeRecordInsert", 
					"maxKeyQuery",
					"targetHeaderColumns",
					"destinationLocation", 
					"destinationFileFormat" })
public class CDCProperties {

	private static CDCProperties cdcProperties;

	private CDCProperties() {
	}

	@JsonProperty("jobName")
	private String jobName;

	@JsonProperty("jobDescription")
	private String jobDescription;

	@JsonProperty("table")
	private Map<String, Table> table;

	@JsonProperty("newInsertsQuery")
	private String newInsertsQuery;

	@JsonProperty("updatedRecordsInsertsQuery")
	private String updatedRecordsInsertsQuery;

	@JsonProperty("updatedRecordsUpdatesQuery")
	private String updatedRecordsUpdatesQuery;

	@JsonProperty("unchangedRecordsQuery")
	private String unchangedRecordsQuery;

	@JsonProperty("firstTimeRecordInsertQuery")
	private String firstTimeRecordInsertQuery;
	
	@JsonProperty("maxKeyQuery")
	private String maxKeyQuery;

	@JsonProperty("destinationLocation")
	private String destinationLocation;
	
	@JsonProperty("destinationFileFormat")
	private String destinationFileFormat;
	
	@JsonProperty("targetHeaderColumns")
	private String targetHeaderColumns;
	
	private boolean runFirstTime;

	private String destinationJobId;

	private String destinationDate;

	public static CDCProperties getCDCProperties(String jsonFileLocation) throws IOException {

		if (cdcProperties == null) {
			ObjectMapper mapper = new ObjectMapper();
			cdcProperties = mapper.readValue(CDCProperties.class.getResourceAsStream(jsonFileLocation),
					CDCProperties.class);
		}

		return cdcProperties;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public Map<String, Table> getTable() {
		return table;
	}

	public void setTable(Map<String, Table> table) {
		this.table = table;
	}

	public String getNewInsertsQuery() {
		return newInsertsQuery;
	}

	public void setNewInsertsQuery(String newInsertsQuery) {
		this.newInsertsQuery = newInsertsQuery;
	}

	public String getUpdatedRecordsInsertsQuery() {
		return updatedRecordsInsertsQuery;
	}

	public void setUpdatedRecordsInsertsQuery(String updatedRecordsInsertsQuery) {
		this.updatedRecordsInsertsQuery = updatedRecordsInsertsQuery;
	}

	public String getUpdatedRecordsUpdatesQuery() {
		return updatedRecordsUpdatesQuery;
	}

	public void setUpdatedRecordsUpdatesQuery(String updatedRecordsUpdatesQuery) {
		this.updatedRecordsUpdatesQuery = updatedRecordsUpdatesQuery;
	}

	public String getUnchangedRecordsQuery() {
		return unchangedRecordsQuery;
	}

	public void setUnchangedRecordsQuery(String unchangedRecordsQuery) {
		this.unchangedRecordsQuery = unchangedRecordsQuery;
	}

	public boolean isRunFirstTime() {
		return runFirstTime;
	}

	public void setRunFirstTime(boolean runFirstTime) {
		this.runFirstTime = runFirstTime;
	}

	public String getDestinationLocation() {
		return destinationLocation;
	}

	public void setDestinationLocation(String destinationLocation) {
		this.destinationLocation = destinationLocation;
	}

	public String getFirstTimeRecordInsertQuery() {
		return firstTimeRecordInsertQuery;
	}

	public void setFirstTimeRecordInsertQuery(String firstTimeRecordInsertQuery) {
		this.firstTimeRecordInsertQuery = firstTimeRecordInsertQuery;
	}
	
	public String getDestinationFileFormat() {
		return destinationFileFormat;
	}

	public void setDestinationFileFormat(String destinationFileFormat) {
		this.destinationFileFormat = destinationFileFormat;
	}

	public String getDestinationJobId() {
		return destinationJobId;
	}

	public void setDestinationJobId(String destinationJobId) {
		this.destinationJobId = destinationJobId;
	}

	public String getDestinationDate() {
		return destinationDate;
	}

	public void setDestinationDate(String destinationDate) {
		this.destinationDate = destinationDate;
	}

	public String getMaxKeyQuery() {
		return maxKeyQuery;
	}

	public void setMaxKeyQuery(String maxKeyQuery) {
		this.maxKeyQuery = maxKeyQuery;
	}

	public String getTargetHeaderColumns() {
		return targetHeaderColumns;
	}

	public void setTargetHeaderColumns(String targetHeaderColumns) {
		this.targetHeaderColumns = targetHeaderColumns;
	}

}
