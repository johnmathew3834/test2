package com.leggmason.edm.edw.helper;

public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		CommandLineArgs arg =  new CommandLineArgs(args);
		//System.out.println(CDCProperties.getCDCProperties("/product.json").getTable().get("master").getFileType());
		System.out.println(arg.isRunFirstTime());
		System.out.println(arg.getMetaFileLocation());
	}

}
