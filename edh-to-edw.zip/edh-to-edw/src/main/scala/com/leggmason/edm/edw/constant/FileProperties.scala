package com.leggmason.edm.edw.constant

object FileProperties {
  
  object FileExtension extends Enumeration {
    val TXT, CSV, JSON, NONE = Value;
  }

  object FileFormat extends Enumeration {
    val TEXT, CSV, JSON = Value;
    
  }
}