package com.leggmason.edm.edw.driver

trait BaseDriver {
    def initilize(spark:org.apache.spark.sql.SparkSession) {
      spark.sparkContext.hadoopConfiguration.set("fs.s3.awsAccessKeyId", "AKIAI6PHGUVBDF4DUUTA")
      spark.sparkContext.hadoopConfiguration.set("fs.s3.awsSecretAccessKey", "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");
      spark.sparkContext.hadoopConfiguration.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
    }
}