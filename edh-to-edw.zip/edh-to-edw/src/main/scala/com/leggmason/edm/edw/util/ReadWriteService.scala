package com.leggmason.edm.edw.util

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import org.apache.spark.sql.{ DataFrame, Row, SparkSession }
import org.codehaus.plexus.util.FileUtils
import org.apache.commons.lang3.StringUtils

/**
 * Created by himanshu on 8/27/2017.
 */
object ReadWriteService {

  def readAsDF(spark: SparkSession, locasourceFileLocationtion: String, headerString: String, delimiter: String, fileFormat: String): DataFrame = {
    // create the schema from a string, splitting by delimiter
    val schema = StructType(headerString.split(",").map(fieldName => StructField(fieldName, StringType, true)))
   
    StringUtils.upperCase(fileFormat) match {
      case "TEXT" => return spark.read.schema(schema).text(locasourceFileLocationtion)
      case "CSV"  => return spark.read.schema(schema).csv(locasourceFileLocationtion);
      case "PARQUET" => return spark.read.parquet(locasourceFileLocationtion);
    }
    return null
  }

  def read(spark: SparkSession, location: String, format: String): RDD[String] = {
    format match {
      case "Text" => return spark.sparkContext.textFile(location)
    }

  }

  def write(rdd: RDD[String], location: String, format: String): Unit = {
    FileUtils.deleteDirectory(location)

    format match {
      case "Text" => rdd.saveAsTextFile(location)
    }
  }

  def write(df: DataFrame, location: String, format: String, headerString: String): Unit = {
    FileUtils.deleteDirectory(location)
    
     // create the schema from a string, splitting by delimiter
    var schema:StructType = null;
    if(StringUtils.isNotEmpty(headerString)){
     schema = StructType(headerString.split(",").map(fieldName => StructField(fieldName, StringType, true)))
    }
    StringUtils.upperCase(format) match {
      case "PARQUET" => df.write.parquet(location)
      case "CSV" => df.write.csv(location)
      case "TEXT" => df.write.text(location)
    }
  }

}
