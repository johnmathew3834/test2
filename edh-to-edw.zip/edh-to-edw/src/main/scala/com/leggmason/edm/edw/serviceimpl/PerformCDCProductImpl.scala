package com.leggmason.edm.edw.serviceimpl

import org.apache.spark.sql.SparkSession
import com.leggmason.edm.edw.helper.CDCProperties

/**
  * Created by himanshu on 9/10/2017.
  */
class PerformCDCProductImpl(cdcProperties: CDCProperties, spark: SparkSession) extends PerformCDCImpl(cdcProperties, spark) {

  override def createDataFrames: Unit = {

  }

}
