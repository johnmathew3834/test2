package com.leggmason.edm.edw.helper

object CDCHelper {
  
}