package com.leggmason.edm.edw.constant

object CommonConstant {
  val CDC_TABLE_ALIAS: String = "cdc"
  val MASTER_TABLE_ALIAS: String = "master"
  val FULL_OUTER_JOIN: String = "fullouter"
  val STATUS_COLUMN: String = "EDM_ACTIVE_FL"  
  val EFFCTV_DT: String = "EDM_EFFCTV_DT";
  val XPRTN_DT: String = "EDM_XPRTN_DT";
  val CREATE_TS: String = "EDM_CREATE_TS";
  val UPDT_TS: String = "EDM_UPDT_TS";
  val FORWARD_SLASH: String = "/"
  
  val dateFormat_YYYDDMM: String = "<YYYYDDMM>"
  val JOBID:String= "<JOBID>"

  object Status extends Enumeration {
    val Y,N = Value;
  }
  
  object Dims extends Enumeration {
    val CDC = Value("cdc") 
    val MASTER = Value("master")
  }
}