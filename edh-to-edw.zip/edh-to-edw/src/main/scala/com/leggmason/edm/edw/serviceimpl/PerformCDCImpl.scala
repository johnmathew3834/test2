package com.leggmason.edm.edw.serviceimpl

import org.apache.spark.sql.{ DataFrame, SparkSession }
import org.apache.spark.sql.functions._

import scala.collection.JavaConverters._
import scala.collection.immutable.Map

import com.leggmason.edm.edw.helper.{ CDCProperties, Table }
import com.leggmason.edm.edw.util.ReadWriteService

import com.leggmason.edm.edw.service.PerformCDC
import com.leggmason.edm.edw.constant.CommonConstant
import org.apache.commons.lang3.StringUtils
import com.leggmason.edm.edw.constant.CommonConstant.Dims

/**
 * Class used to perform CDC Operations between two data frames
 * Created by himanshu on 6/4/2017.
 */
class PerformCDCImpl(cdcProperties: CDCProperties, spark: SparkSession) extends PerformCDC {

  override def createDataFrames: Unit = {

    val tables: scala.collection.immutable.Map[String, Table] = cdcProperties.getTable.asScala.toMap;
    var sourceLocation: String = null;
    for ((name: String, table: Table) <- tables) {
      if (cdcProperties.isRunFirstTime()) {
        //If first time running the source then load only CDC data since master not avail.
        if (StringUtils.contains(name, Dims.CDC.toString())) {
          sourceLocation = resolveS3Path(table.getSourceLocation, "20170915", "2319")
          val df = ReadWriteService.readAsDF(spark, sourceLocation, table.getHeaderString, table.getDelimiter, table.getFileFormat)
          df.createOrReplaceTempView(table.getTableName)
        }
      } else {
        sourceLocation = resolveS3Path(table.getSourceLocation, "20170915", "2319")
        val df = ReadWriteService.readAsDF(spark, sourceLocation, table.getHeaderString, table.getDelimiter, table.getFileFormat)
        df.createOrReplaceTempView(table.getTableName)
      }
    }
  }

  
  def getMaxId: String = {
    // TODO - Handle scenario if count is zero
    return spark.sql(cdcProperties.getMaxKeyQuery).head().getString(0)
  }
  
  override def getNewRecords: DataFrame = {

     val max = getMaxId

    val rdd = spark.sql(cdcProperties.getNewInsertsQuery)
      .withColumn(CommonConstant.STATUS_COLUMN, lit(CommonConstant.Status.Y.toString))
      .withColumn(CommonConstant.EFFCTV_DT, current_date())
      .withColumn(CommonConstant.XPRTN_DT, lit("9999-12-31"))
      .withColumn(CommonConstant.CREATE_TS, current_timestamp())
      .withColumn(CommonConstant.UPDT_TS, current_timestamp())

    rdd.createOrReplaceTempView("new_records")

    val sql = "select row_number() over (order by 1) + " + max + " as " + cdcProperties.getTargetHeaderColumns + " from new_records";


    return spark.sql(sql)

  }

  override def getUpdatedRecordsNew: DataFrame = {

     return spark.sql(cdcProperties.getUpdatedRecordsInsertsQuery)
      .withColumn(CommonConstant.STATUS_COLUMN, lit(CommonConstant.Status.Y.toString))
      .withColumn(CommonConstant.EFFCTV_DT, current_date())
      // TODO - Move to constants
      .withColumn(CommonConstant.XPRTN_DT, lit("9999-12-31"))
      .withColumn(CommonConstant.CREATE_TS, current_timestamp())
      .withColumn(CommonConstant.UPDT_TS, current_timestamp())
  }

  override def getUpdatedRecordsOld: DataFrame = {
   return spark.sql(cdcProperties.getUpdatedRecordsUpdatesQuery)
  }

  override def getNotChangedRecordsMaster: DataFrame = {
    return spark.sql(cdcProperties.getUnchangedRecordsQuery)

  }

  override def getFinalResults(newRecords: DataFrame, updatedRecordsNew: DataFrame, updatedRecordsOld: DataFrame,
                               notChangedRecords: DataFrame): DataFrame = {
    return newRecords.union(updatedRecordsNew).union(updatedRecordsOld).union(notChangedRecords).coalesce(1)
  }

  override def getFirstTimerecords: DataFrame = {
    return spark.sql(cdcProperties.getFirstTimeRecordInsertQuery)
      .withColumn(CommonConstant.STATUS_COLUMN, lit(CommonConstant.Status.Y.toString))
  }

  /**
   * Driver method for this class
   *
   * @return Returns final data frame
   */
  override def run() = {

    createDataFrames

    var finalOutput: DataFrame = null;

    if (cdcProperties.isRunFirstTime()) {
      finalOutput = getFirstTimerecords;
    } else {
      val newRecords = getNewRecords
      val updatedRecordsNew = getUpdatedRecordsNew
      val updatedRecordOld = getUpdatedRecordsOld
      val noChangedRecords = getNotChangedRecordsMaster
      finalOutput = getFinalResults(newRecords, updatedRecordsNew, updatedRecordOld, noChangedRecords)
    }
    
    //write output to respective destination location
    ReadWriteService.write(finalOutput, resolveS3Path(cdcProperties.getDestinationLocation, "20170915", "2319"),cdcProperties.getDestinationFileFormat(),cdcProperties.getTargetHeaderColumns)
  }

  def resolveS3Path(path: String, date: String, jobId: String): String = {
    var pathLoc: String = null;
    pathLoc = StringUtils.replace(path, CommonConstant.dateFormat_YYYDDMM, date)
    pathLoc = StringUtils.replace(pathLoc, CommonConstant.JOBID, jobId)
    pathLoc
  }

}
