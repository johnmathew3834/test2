package com.leggmason.edm.edw.helper

import com.leggmason.edm.edw.service.PerformCDC
import com.leggmason.edm.edw.serviceimpl.PerformCDCImpl
import com.leggmason.edm.edw.helper.CDCProperties

import org.apache.spark.sql.SparkSession
import org.apache.commons.lang3.StringUtils
import com.leggmason.edm.edw.serviceimpl.PerformCDCProductImpl


object CDCObjectFactory extends CDCFactory {
    //Give job name should be small in below. 
    implicit  def create(jobName: String, cdcProperties: CDCProperties, spark: SparkSession): PerformCDC = StringUtils.lowerCase(jobName) match {
      case product_cdc: String  => new PerformCDCImpl(cdcProperties, spark)
      case i: String => new PerformCDCProductImpl(cdcProperties, spark)
      
    }
  }