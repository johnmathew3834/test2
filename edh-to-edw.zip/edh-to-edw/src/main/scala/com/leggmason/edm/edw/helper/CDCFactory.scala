package com.leggmason.edm.edw.helper

import com.leggmason.edm.edw.service.PerformCDC
import com.leggmason.edm.edw.helper.CDCProperties

import org.apache.spark.sql.SparkSession

trait CDCFactory {
  def create(jobName: String, cdcProperties: CDCProperties, spark: SparkSession): PerformCDC
}