package com.leggmason.edm.edw.driver

import org.apache.spark.sql.SparkSession

import org.codehaus.plexus.util.FileUtils
import com.leggmason.edm.edw.helper.{CDCProperties, CommandLineArgs}

import com.leggmason.edm.edw.serviceimpl.PerformCDCImpl
import com.leggmason.edm.edw.helper.CDCProperties;
import com.leggmason.edm.edw.helper.CDCObjectFactory
import com.leggmason.edm.edw.constant.CommonConstant

/**
  * Generic Entry point for spark for common CDC operations
  * Created by himanshu on 6/4/2017.
  */
object EDWDriver extends BaseDriver {

  def main(args: Array[String]): Unit = {
    
    
    //Verify command line arguments
    val commandLineArgs = new CommandLineArgs(args)

    //Convert input json to an object
    val cdcProperties = CDCProperties.getCDCProperties(CommonConstant.FORWARD_SLASH+commandLineArgs.getMetaFileLocation)

    cdcProperties.setRunFirstTime(commandLineArgs.isRunFirstTime())
    
    
    //Create spark session
    val spark = SparkSession.builder().appName(cdcProperties.getJobName).getOrCreate()
    
    initilize(spark)
    
    val cdcObject = CDCObjectFactory.create(cdcProperties.getJobName,cdcProperties, spark);

    //Perform CDC
    val finalOutput = cdcObject.run()


  }

}
