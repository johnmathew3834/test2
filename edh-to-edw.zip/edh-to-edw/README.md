# SparkRDDs
Examples for practicing RDDs with Spark using scala

This app also contains an example of how to perform CDC operations for a typical Data Warehousing application
using Spark and Scala.
