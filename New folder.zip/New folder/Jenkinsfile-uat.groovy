node {
    stage('Preparation') { // for display purposes
        // Get EDM code from a GitHub repository
        cleanWs()
        checkout scm
        sh "python $WORKSPACE/deployment_scripts/replace_tokens.py --localFolder $WORKSPACE --env uat"
    }
    stage('Build') {
        // Run the maven build
        sh "chmod 775 $WORKSPACE/deployment_scripts/build.sh"
        sh "$WORKSPACE/deployment_scripts/build.sh $WORKSPACE uat"
    }
    stage('Deploy') {
        //Run the deployment script
        sh "python $WORKSPACE/deployment_scripts/edm_deploy.py $WORKSPACE lm-edm-builds-uat ${env.BUILD_NUMBER} uat $WORKSPACE/deployment_scripts/config.json"
    }
}