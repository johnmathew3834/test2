package org.lm.edh.api.product.util;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource(value = "classpath:application.properties")
public class SysEnvironment {

    @Autowired
    private  Environment systemEnvironment;

    public String getPropertyValue(String key) {
        return systemEnvironment.getProperty(key);
    }
}
