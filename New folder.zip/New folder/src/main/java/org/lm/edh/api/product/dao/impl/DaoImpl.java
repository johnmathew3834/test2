package org.lm.edh.api.product.dao.impl;

import org.apache.log4j.Logger;
import org.lm.edh.api.product.dao.Dao;
import org.lm.edh.api.product.model.entity.APIResponse;
import org.lm.edh.api.product.model.entity.Pagination;
import org.lm.edh.api.product.model.entity.Product;
import org.lm.edh.api.product.util.Constants;
import org.lm.edh.api.product.util.SysEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by vkalakotahe7160 on 11/1/2019.
 */
@Repository
@Qualifier("Dao")
public class DaoImpl implements Dao {

    private static final Logger LOGGER = Logger.getLogger(DaoImpl.class.getName());

    @Autowired
    @Qualifier("jdbcIDH")
    private JdbcTemplate edhJdbcTemplate;

    @Autowired
    private SysEnvironment environment;

    private String awaProductTable;

    @Override
    public APIResponse getAllProducts() {
        LOGGER.info("Begin getAllProducts()");
        APIResponse apiResponse = new APIResponse();
        StringBuilder sqlBuffSelect = new StringBuilder();
        StringBuilder sqlBuffFrom = new StringBuilder();
        StringBuilder sqlBuffTotCount = new StringBuilder();

        int recordsLimit = Integer.parseInt(environment.getPropertyValue(Constants.NUM_ROWS_LIMIT));
        int totalCount=0;

        awaProductTable = environment.getPropertyValue(Constants.SQL_AWA_PRODUCT_TABLE);

        sqlBuffSelect.append(environment.getPropertyValue(Constants.SQL_AWA_SELECT));

        sqlBuffFrom.append(awaProductTable);

        LOGGER.debug(" sqlBuffFrom SQL :: " + sqlBuffFrom.toString());
        LOGGER.debug(" sqlBuffSelect SQL :: " + sqlBuffSelect.toString());

        String limit = " limit " + recordsLimit;
        sqlBuffTotCount.append("SELECT count(*) ");

        try {
            sqlBuffTotCount.append(sqlBuffFrom.toString());

            LOGGER.debug(" sqlBuffTotCount SQL :: " + sqlBuffTotCount.toString());
            try {
                totalCount = edhJdbcTemplate.queryForObject(sqlBuffTotCount.toString(), Integer.class);
            }catch (Exception e){
                e.printStackTrace();
                LOGGER.error("Exception ",e);
            }

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error("Exception processing total records count:: ", e);
            totalCount = 0;
        }

        processPagination(totalCount, recordsLimit, apiResponse);
        LOGGER.info("Total Products available :: " + totalCount);

        String sqlFetchProducts = sqlBuffSelect.append(sqlBuffFrom).append(limit).toString();
        LOGGER.debug("Products SQL :: " + sqlFetchProducts);

        List<Product> products = edhJdbcTemplate.query(sqlFetchProducts, new BeanPropertyRowMapper<>(Product.class));
        LOGGER.debug(" Total products retrieved :: " + products.size());

        apiResponse.setAdvisoryWorldAssets(products);
        return apiResponse;
    }

    @Override
    public APIResponse getAWProducts(LocalDate fromDt, LocalDate toDt, String morningStarId) {

        APIResponse apiResponse = new APIResponse();
        StringBuilder sqlBuffDeltaInd = new StringBuilder();
        StringBuilder sqlBuffDeltaIndMaxDate = new StringBuilder();
        StringBuilder sqlBuffWhereClause = new StringBuilder();
        StringBuilder sqlBuffTotCount = new StringBuilder();
        StringBuilder sqlBuffMaxDateWhereClause = new StringBuilder();
        StringBuilder sqlBuffSelect = new StringBuilder();
        int totalCount;

        awaProductTable = environment.getPropertyValue(Constants.SQL_AWA_PRODUCT_TABLE);
        Date fromDate = (!StringUtils.isEmpty(fromDt)) ? Date.valueOf(fromDt) : null;
        Date toDate = (!StringUtils.isEmpty(toDt)) ? Date.valueOf(toDt) : null;

        LOGGER.info("fromDate is :: " + fromDate);
        LOGGER.info("toDate is :: " + toDate);
        LOGGER.info(" Morning Star Id :: " + morningStarId);

        Date maxDateOfData = null;
        boolean isProcessDateOfMaxDate = false;
        int recordsLimit = Integer.parseInt(environment.getPropertyValue(Constants.NUM_ROWS_LIMIT));

        sqlBuffSelect.append(environment.getPropertyValue(Constants.SQL_AWA_SELECT));

        if (StringUtils.isEmpty(fromDate) && StringUtils.isEmpty(toDate)) {
            maxDateOfData = fetchMaxModifiedDate();
            isProcessDateOfMaxDate = true;
            LOGGER.info("Latest date data processed :: " + maxDateOfData);

            sqlBuffDeltaIndMaxDate.append(environment.getPropertyValue(Constants.SQL_AWA_DELTA_MAX_DT_CASE));
            sqlBuffMaxDateWhereClause.append(awaProductTable + " "+ environment.getPropertyValue(Constants.SQL_AWA_MAX_DT_WHERE_CLAUSE));

            if (!StringUtils.isEmpty(morningStarId)) {
                sqlBuffMaxDateWhereClause.append(environment.getPropertyValue(Constants.SQL_AWA_MORNING_STAR_ID));
            }
        } else {
            sqlBuffDeltaInd.append(environment.getPropertyValue(Constants.SQL_AWA_DELTA_CASE));
            sqlBuffWhereClause.append(awaProductTable +" "+ environment.getPropertyValue(Constants.SQL_AWA_WHERE_CLAUSE));
        }
        if (!StringUtils.isEmpty(morningStarId)) {
            sqlBuffWhereClause.append(environment.getPropertyValue(Constants.SQL_AWA_MORNING_STAR_ID));
        }

        String limit = " limit " + recordsLimit;
        sqlBuffTotCount.append("SELECT count(*) ");

        try {
            if (isProcessDateOfMaxDate) {
                StringBuilder sqlMaxDateCount = new StringBuilder();
                sqlMaxDateCount.append(sqlBuffTotCount).append(sqlBuffMaxDateWhereClause.toString());

                LOGGER.debug(" sqlMaxDateCount SQL :: " + sqlMaxDateCount.toString());

                if (StringUtils.isEmpty(morningStarId)) {
                    totalCount = edhJdbcTemplate.queryForObject(sqlMaxDateCount.toString(), new Object[]{maxDateOfData, maxDateOfData}, Integer.class);
                } else {
                    totalCount = edhJdbcTemplate.queryForObject(sqlMaxDateCount.toString(), new Object[]{maxDateOfData, maxDateOfData, morningStarId}, Integer.class);
                }
            } else {
                String sqlCount = sqlBuffTotCount.append(sqlBuffWhereClause).toString();
                LOGGER.debug(" sqlCount SQL :: " + sqlCount);
                if (StringUtils.isEmpty(morningStarId)) {
                    totalCount = edhJdbcTemplate.queryForObject(sqlCount, new Object[]{fromDate, toDate, fromDate, toDate}, Integer.class);
                } else {
                    totalCount = edhJdbcTemplate.queryForObject(sqlCount, new Object[]{fromDate, toDate, fromDate, toDate, morningStarId}, Integer.class);
                }
            }
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error("Exception processing total products count :: ", e);
            totalCount = 0;
        }
        LOGGER.info("Total Products available :: " + totalCount);

        processPagination(totalCount, recordsLimit, apiResponse);

        List<Product> awAssets;
        if (isProcessDateOfMaxDate) {
            String sqlFetchMaxDateProducts = sqlBuffSelect.append(sqlBuffDeltaIndMaxDate).append(sqlBuffMaxDateWhereClause).append(limit).toString();
            LOGGER.info(" Max processed date products SQL :: " + sqlFetchMaxDateProducts);

            if (StringUtils.isEmpty(morningStarId)) {
                awAssets = edhJdbcTemplate.query(sqlFetchMaxDateProducts, new Object[]{maxDateOfData, maxDateOfData, maxDateOfData}, new BeanPropertyRowMapper<>(Product.class));
            } else {
                awAssets = edhJdbcTemplate.query(sqlFetchMaxDateProducts, new Object[]{maxDateOfData, maxDateOfData, maxDateOfData, morningStarId}, new BeanPropertyRowMapper<>(Product.class));
            }
        } else {
            String sqlFetchProducts = sqlBuffSelect.append(sqlBuffDeltaInd).append(sqlBuffWhereClause).append(limit).toString();
            LOGGER.debug(" Date Range products SQL :: " + sqlFetchProducts);

            if (StringUtils.isEmpty(morningStarId)) {
                awAssets = edhJdbcTemplate.query(sqlFetchProducts, new Object[]{fromDate, toDate, fromDate, toDate, fromDate, toDate}, new BeanPropertyRowMapper<>(Product.class));
            } else {
                awAssets = edhJdbcTemplate.query(sqlFetchProducts, new Object[]{fromDate, toDate, fromDate, toDate, fromDate, toDate, morningStarId}, new BeanPropertyRowMapper<>(Product.class));
            }
        }

        LOGGER.debug(" Total products retrieved :: " + awAssets.size());
        apiResponse.setAdvisoryWorldAssets(awAssets);

        return apiResponse;
    }

    @Override
    public APIResponse getAWProductsByMorningStartId(String morningStarId) {

        APIResponse apiResponse = new APIResponse();
        StringBuilder sqlBuffDeltaInd = new StringBuilder();
        StringBuilder sqlBuffWhereClause = new StringBuilder();
        StringBuilder sqlBuffTotCount = new StringBuilder();
        StringBuilder sqlBuffSelect = new StringBuilder();
        int recordsLimit = Integer.parseInt(environment.getPropertyValue(Constants.NUM_ROWS_LIMIT));
        int totalCount;

        awaProductTable = environment.getPropertyValue(Constants.SQL_AWA_PRODUCT_TABLE);

        LOGGER.info(" Morning Star Id :: " + morningStarId);

        sqlBuffSelect.append(environment.getPropertyValue(Constants.SQL_AWA_SELECT));

        sqlBuffDeltaInd.append(environment.getPropertyValue(Constants.SQL_AWA_DELTA_CASE_ID));
        sqlBuffWhereClause.append(awaProductTable +" "+ environment.getPropertyValue(Constants.SQL_AWA_ID_WHERE_CLAUSE));

        String limit = " limit " + recordsLimit;
        sqlBuffTotCount.append("SELECT count(*) ");

        try {
            StringBuilder sqlMaxDateCount = new StringBuilder();
            sqlMaxDateCount.append(sqlBuffTotCount).append(sqlBuffWhereClause.toString());

            LOGGER.debug(" sqlMaxDateCount SQL :: " + sqlMaxDateCount.toString());
            totalCount = edhJdbcTemplate.queryForObject(sqlMaxDateCount.toString(), new Object[]{morningStarId}, Integer.class);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error("Exception processing total records count:: ", e);
            totalCount = 0;
        }

        processPagination(totalCount, recordsLimit, apiResponse);
        LOGGER.info("Total Products available :: " + totalCount);

        String sqlFetchProductsById = sqlBuffSelect.append(sqlBuffDeltaInd).append(sqlBuffWhereClause).append(limit).toString();
        LOGGER.debug("Products SQL by ID :: " + sqlFetchProductsById);

        List<Product> products = edhJdbcTemplate.query(sqlFetchProductsById, new Object[]{morningStarId}, new BeanPropertyRowMapper<>(Product.class));
        LOGGER.debug(" Total products retrieved :: " + products.size());

        apiResponse.setAdvisoryWorldAssets(products);
        return apiResponse;
    }

    private Date fetchMaxModifiedDate() {

        String query = environment.getPropertyValue(Constants.SQL_AWA_MAX_DATA_PROCESSED_DT) + " " + awaProductTable;
        final Date date = edhJdbcTemplate.queryForObject(query, new Object[]{}, Date.class);
        return date;
    }

    private APIResponse processPagination(int totalCount, int recordsLimit, APIResponse apiResponse) {

        // Pagination
        if (totalCount > 0) {
            Pagination page = new Pagination();
            page.setTotalAvailable(BigInteger.valueOf(totalCount));
            page.setPageSize(BigInteger.valueOf(recordsLimit));
            page.setPageNumber(BigInteger.valueOf(1));
            apiResponse.setPagination(page);
        }
        return apiResponse;
    }

}
