package org.lm.edh.api.product.dao;

import org.lm.edh.api.product.model.entity.APIResponse;
import org.lm.edh.api.product.model.entity.Product;

import java.time.LocalDate;


/**
 * Created by vkalakotahe7160 on 11/1/2019.
 */
public interface Dao {

    public APIResponse getAllProducts();

    public APIResponse getAWProducts(LocalDate fromDt, LocalDate toDt, String morningStarId);

    public APIResponse getAWProductsByMorningStartId(String morningStarId);


}
