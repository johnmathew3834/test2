package org.lm.edh.api.product.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.lm.edh.api.product.util.Constants;
import org.lm.edh.api.product.util.GetSecret;
import org.lm.edh.api.product.util.SysEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

import static org.apache.log4j.Logger.getLogger;

import java.util.Map;

@Configuration
public class EDHDataSourceConfig {

    private static final Logger logger = getLogger(EDHDataSourceConfig.class.getName());
    @Autowired
    private SysEnvironment environment;

    @Autowired
    private GetSecret secret;

    /*@Bean(name = "dsEDH")
    public DataSource edmDataSource() {

        BasicDataSource edm = new BasicDataSource();
        try {
            edm.setUrl(secret.getSecretValue(environment.getPropertyValue(Constants.EDH_DB_CONN_URL)
            ));
            edm.setDriverClassName(environment.getPropertyValue("spring.ds.edh.driver-class-name"));
            edm.setUsername(secret.getSecretValue(environment.getPropertyValue(Constants.EDH_DB_USER)));
            edm.setPassword(secret.getSecretValue(environment.getPropertyValue(Constants.EDH_DB_PASSWORD)));

        } catch (JSONException e) {
            logger.error("Exception fetching Secrets Manager values", e);
        }
        return edm;
    }*/

    //uncomment for running in local with credentials
    @Bean(name = "dsIDH")
    public DataSource edmDataSource1() {
    	Map<String, String> getCred = null;
    	try {
    		getCred = secret.getSecretValue(Constants.EDH_DB_CONN_URL, Constants.EDH_DB_USER, Constants.EDH_DB_PASSWORD);
    	} catch (JSONException e) {
            logger.error("Exception fetching Secrets Manager values", e);
            throw new RuntimeException("Secrets loading issue");
        }
        BasicDataSource idh = new BasicDataSource();
        idh.setUrl(getCred.get(Constants.EDH_DB_CONN_URL));
        idh.setDriverClassName(Constants.EDH_DB_DRIVER);
        idh.setUsername(getCred.get(Constants.EDH_DB_USER));
        idh.setPassword(getCred.get(Constants.EDH_DB_PASSWORD));
        idh.addConnectionProperty("CLIENT_SESSION_KEEP_ALIVE", "true");

        return idh;
    }

    @Bean(name = "jdbcIDH")
    @Autowired
    public JdbcTemplate edmJdbcTemplate(@Qualifier("dsIDH") DataSource datasource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }

}
