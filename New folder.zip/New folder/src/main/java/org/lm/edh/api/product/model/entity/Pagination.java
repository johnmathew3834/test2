package org.lm.edh.api.product.model.entity;

import java.math.BigInteger;

/**
 * Created by vkalakotahe7160 on 11/2/2019
 */

public class Pagination {

    private BigInteger pageNumber;
    private BigInteger pageSize;
    private BigInteger totalAvailable;

    public BigInteger getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(BigInteger pageNumber) {
        this.pageNumber = pageNumber;
    }

    public BigInteger getPageSize() {
        return pageSize;
    }

    public void setPageSize(BigInteger pageSize) {
        this.pageSize = pageSize;
    }

    public BigInteger getTotalAvailable() {
        return totalAvailable;
    }

    public void setTotalAvailable(BigInteger totalAvailable) {
        this.totalAvailable = totalAvailable;
    }
}
