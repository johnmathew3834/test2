package org.lm.edh.api.product.util;

/**
 * Constants for Product API
 */
public class Constants {

    private Constants(){
        throw new IllegalStateException("Constants class");
    }

    public static final String SQL_AWA_SELECT = "awaSelectQuery";
    public static final String SQL_AWA_DELTA_CASE = "awaDeltaCase";

    public static final String SQL_AWA_DELTA_MAX_DT_CASE = "awaDeltaCaseMaxDt";

    public static final String SQL_AWA_DELTA_CASE_ID = "awaDeltaCaseMorningStarId";

    public static final String SQL_AWA_WHERE_CLAUSE = "awaWhereClause";

    public static final String SQL_AWA_ID_WHERE_CLAUSE = "awaIdWhereClause";

    public static final String SQL_AWA_MORNING_STAR_ID = "awaMorningStarId";

    public static final String SQL_AWA_MAX_DT_WHERE_CLAUSE = "awaMaxDateWhereClause";

    public static final String SQL_AWA_MAX_DATA_PROCESSED_DT = "awaMaxDataProcessedDate";

    public static final String SQL_AWA_PRODUCT_TABLE = "awaProductTable";

    public static final String NUM_ROWS_LIMIT = "numOfRowsLimit";

    public static final String NUM_DAYS_TO_FETCH = "numOfDaysToFetch";

    //Validation messages
    public static final String VALIDATION_AWA_FUTURE_DT = "msgFutureDate";
    public static final String VALIDATION_AWA_LATER_DT = "msgLaterDt";

    public static final String EDH_DB_DRIVER="net.snowflake.client.jdbc.SnowflakeDriver";
    public static final String EDH_DB_USER = "spring.ds.idh.username";
    public static final String EDH_DB_PASSWORD = "spring.ds.idh.password";
    public static final String EDH_DB_CONN_URL = "spring.ds.idh.url";
    public static final String EDH_PRODUCT_API_SECRETS = "secretsName";




}
