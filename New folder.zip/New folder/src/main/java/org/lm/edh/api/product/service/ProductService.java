package org.lm.edh.api.product.service;

import org.lm.edh.api.product.dao.Dao;
import org.lm.edh.api.product.model.entity.APIResponse;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;

/**
 * Created by vkalakotahe7160 on 11/1/2019.
 */
@org.springframework.stereotype.Service
public class ProductService {

    @Autowired
    Dao dao;

    public APIResponse fetchAwProducts(LocalDate fromDt, LocalDate toDt, String morningstarId) {
        return dao.getAWProducts(fromDt, toDt, morningstarId);
    }

    public APIResponse fetchAwProductsById(String morningStarId) {
        return dao.getAWProductsByMorningStartId(morningStarId);
    }

    public APIResponse fetchAllProducts() {
        return dao.getAllProducts();
    }

}
