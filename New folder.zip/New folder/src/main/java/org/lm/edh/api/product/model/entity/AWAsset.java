package org.lm.edh.api.product.model.entity;

public class AWAsset {

    private String name;
    private String symbol;
    private String morningstarId;
    private String morningstarCategory;
    private String fundId;
    private String fundLegalName;
    private String shareClass;
    private String type;
    private String isOldestShareClassFlag;
    private String createdDt;
    private String modifiedDt;
    private String deltaIndicator;
// Added for release 2
    private String firmName;
    private String lipperCategory;
    private String fundFamilyName;
    private String beginDt;
    private String endDt;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getMorningstarId() {
        return morningstarId;
    }

    public void setMorningstarId(String morningstarId) {
        this.morningstarId = morningstarId;
    }

    public String getMorningstarCategory() {
        return morningstarCategory;
    }

    public void setMorningstarCategory(String morningstarCategory) {
        this.morningstarCategory = morningstarCategory;
    }

    public String getFundId() {
        return fundId;
    }

    public void setFundId(String fundId) {
        this.fundId = fundId;
    }

    public String getFundLegalName() {
        return fundLegalName;
    }

    public void setFundLegalName(String fundLegalName) {
        this.fundLegalName = fundLegalName;
    }

    public String getShareClass() {
        return shareClass;
    }

    public void setShareClass(String shareClass) {
        this.shareClass = shareClass;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsOldestShareClassFlag() {
        return isOldestShareClassFlag;
    }

    public void setIsOldestShareClassFlag(String isOldestShareClassFlag) {
        this.isOldestShareClassFlag = isOldestShareClassFlag;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(String modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    public String getDeltaIndicator() {
        return deltaIndicator;
    }

    public void setDeltaIndicator(String deltaIndicator) {
        this.deltaIndicator = deltaIndicator;
    }

    public String getFirmName() {
        return firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getLipperCategory() {
        return lipperCategory;
    }

    public void setLipperCategory(String lipperCategory) {
        this.lipperCategory = lipperCategory;
    }

    public String getFundFamilyName() {
        return fundFamilyName;
    }

    public void setFundFamilyName(String fundFamilyName) {
        this.fundFamilyName = fundFamilyName;
    }

    public String getBeginDt() {
        return beginDt;
    }

    public void setBeginDt(String beginDt) {
        this.beginDt = beginDt;
    }

    public String getEndDt() {
        return endDt;
    }

    public void setEndDt(String endDt) {
        this.endDt = endDt;
    }

    @Override
    public String toString() {
        return "AWAsset{" +
                "name='" + name + '\'' +
                ", symbol='" + symbol + '\'' +
                ", morningstarId='" + morningstarId + '\'' +
                ", morningstarCategory='" + morningstarCategory + '\'' +
                ", fundId='" + fundId + '\'' +
                ", fundLegalName='" + fundLegalName + '\'' +
                ", shareClass='" + shareClass + '\'' +
                ", type='" + type + '\'' +
                ", isOldestShareClassFlag='" + isOldestShareClassFlag + '\'' +
                ", createdDt='" + createdDt + '\'' +
                ", modifiedDt='" + modifiedDt + '\'' +
                ", deltaIndicator='" + deltaIndicator + '\'' +
                ", firmName='" + firmName + '\'' +
                ", lipperCategory='" + lipperCategory + '\'' +
                ", fundFamilyName='" + fundFamilyName + '\'' +
                ", beginDt='" + beginDt + '\'' +
                ", endDt='" + endDt + '\'' +
                '}';
    }
}
