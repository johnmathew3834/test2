package org.lm.edh.api.product.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.log4j.Logger;
import org.lm.edh.api.product.exception.ProductException;
import org.lm.edh.api.product.model.entity.APIResponse;
import org.lm.edh.api.product.service.ProductService;
import org.lm.edh.api.product.util.Constants;
import org.lm.edh.api.product.util.SysEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Created by vkalakotahe7160 on 11/2/2019.
 */
@CrossOrigin(allowCredentials = "true")
@RestController
@RequestMapping("/")
@Api(value = "products", description = "Operations pertaining to products in EDH")
public class ProductController {

    private static final Logger LOGGER = Logger.getLogger(ProductController.class.getName());
    @Autowired
    ProductService service;
    @Autowired
    private SysEnvironment environment;

    /*@Autowired
    private GetSecret getSecret;
    @GetMapping(value = "secret", produces = "application/json")
    public String getSecret(@RequestParam String secretKey) throws JSONException {
        System.out.printf("inside secret value  key is :: "+secretKey);
        return getSecret.getSecretValue(secretKey);
    }*/

    /* Added for release 2 */
    @ApiOperation(value = "View a list of advisory world assets", response = APIResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
            @ApiResponse(code = 500, message = "There is an internal server error")
    }
    )

    @GetMapping(value = "v2/awa", produces = "application/json")
    public ResponseEntity<Object> getAdvisoryWorldAssets(@RequestParam Optional<String> id) {
        Instant start = Instant.now();
        String URIPath = null;
        try {
            //int numOfDaysToFetch = Integer.parseInt(environment.getPropertyValue(Constants.NUM_DAYS_TO_FETCH));

            String morningStarId = (id.isPresent()) ? id.get() : null;
            LOGGER.info("id value:: "+morningStarId);
            URIPath = buildURIPath(morningStarId);

            if (!StringUtils.isEmpty(morningStarId)) {
                // Req 5 - no from and to Dates
                return ResponseEntity.status(200).body(service.fetchAwProductsById(morningStarId));
            }
            return ResponseEntity.status(200).body(service.fetchAllProducts());

        } catch (Exception ex) {
            LOGGER.error("Exception Occurred in controller :: ", ex);
            return ResponseEntity.status(500).body(processCustomException(ex, URIPath));
        } finally {
            Instant finish = Instant.now();

            long timeElapsed = Duration.between(start, finish).getSeconds();
            LOGGER.info("URI Path :: " + URIPath + " response took " + timeElapsed + " seconds to complete");
        }

    }

    @GetMapping(value = "healthCall", produces = "application/json")
    public ResponseEntity<Object> HealthCall() {
       return ResponseEntity.status(200).body("Success:Up");
    }

        @ApiOperation(value = "View a list of advisory world assets", response = APIResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
            @ApiResponse(code = 500, message = "There is an internal server error")
    }
    )
    @GetMapping(value = "v1/awa", produces = "application/json")
    public ResponseEntity<Object> getAdvisoryWorldAssets(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Optional<LocalDate> fromDt,
                                                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Optional<LocalDate> toDt,
                                                         @RequestParam Optional<String> id) {
        Instant start = Instant.now();
        String URIPath = null;
        try {
            int numOfDaysToFetch = Integer.parseInt(environment.getPropertyValue(Constants.NUM_DAYS_TO_FETCH));

            // Date pattern - yyyy-MM-dd, e.g. 2015-03-01 - Sample URI http://localhost:8080/products/v1/awa?fromDt=2019-10-25&toDt=2019-10-30&id=F00011
            LocalDate fromDate = (fromDt.isPresent()) ? fromDt.get() : null;
            LocalDate toDate = (toDt.isPresent()) ? toDt.get() : null;
            String morningStarId = (id.isPresent()) ? id.get() : null;

            URIPath = buildURIPath(fromDate, toDate, morningStarId);

            // today's date
            LocalDate currentDate = LocalDate.now();

            if (!StringUtils.isEmpty(fromDate) && fromDate.isAfter(currentDate)) {
                // future date validation
                return ResponseEntity.badRequest().body(processValidationException(environment.getPropertyValue(Constants.VALIDATION_AWA_FUTURE_DT), URIPath));
            }
            // both present #Req 1
            if (!StringUtils.isEmpty(fromDate) && !StringUtils.isEmpty(toDate)) {

                // from date should not be later to to date Validation
                if (fromDate.isAfter(toDate)) {
                    return ResponseEntity.badRequest().body(processValidationException(environment.getPropertyValue(Constants.VALIDATION_AWA_LATER_DT), URIPath));
                }
                //#Req 2
                long daysBetween = DAYS.between(fromDate, toDate);
                LOGGER.info("Days difference :: " + daysBetween);
                LOGGER.info("Num of days to default :: " + numOfDaysToFetch);

                if (daysBetween > (numOfDaysToFetch - 1)) {
                    // If days to default is 7 then add 6 to fromDate to have 7 days added.
                    toDate = fromDt.get().plusDays(numOfDaysToFetch - 1);
                    LOGGER.info("To Date adjusted to :: " + toDate.toString());
                }

            } else if (StringUtils.isEmpty(fromDate) && !StringUtils.isEmpty(toDate)) {

                // #REQ 3 - No from date
                fromDate = toDate.minusDays(numOfDaysToFetch - 1);
            } else if (!StringUtils.isEmpty(fromDate) && StringUtils.isEmpty(toDate)) {

                // Req 4 - No to Date
                toDate = fromDate.plusDays(numOfDaysToFetch - 1);
            } else if (StringUtils.isEmpty(fromDate) && StringUtils.isEmpty(toDate) && !StringUtils.isEmpty(morningStarId)) {
                // Req 5 - no from and to Dates
                return ResponseEntity.status(200).body(service.fetchAwProductsById(morningStarId));
            }

            return ResponseEntity.status(200).body(service.fetchAwProducts(fromDate, toDate, morningStarId));

        } catch (Exception ex) {
            LOGGER.error("Exception Occurred in controller :: ", ex);
            return ResponseEntity.status(500).body(processCustomException(ex, URIPath));
        } finally {
            Instant finish = Instant.now();

            long timeElapsed = Duration.between(start, finish).getSeconds();
            LOGGER.info("URI Path :: " + URIPath + " response took " + timeElapsed + " seconds to complete");
        }

    }

    private String buildURIPath(String morningStarId) {

        ServletUriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentRequestUri();


        if (!StringUtils.isEmpty(morningStarId)) {
            builder.replaceQueryParam("id", morningStarId);
        }

        URI newUri = builder.build().toUri();

        return newUri.toString();

    }

    private String buildURIPath(LocalDate fromDate, LocalDate toDate, String morningStarId) {

        ServletUriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentRequestUri();

        if (!StringUtils.isEmpty(fromDate)) {
            builder.replaceQueryParam("fromDt", fromDate);
        }
        if (!StringUtils.isEmpty(toDate)) {
            builder.replaceQueryParam("toDt", toDate);
        }
        if (!StringUtils.isEmpty(morningStarId)) {
            builder.replaceQueryParam("id", morningStarId);
        }

        URI newUri = builder.build().toUri();

        return newUri.toString();

    }

    private ProductException processValidationException(String message, String path) {
        ProductException customException = new ProductException();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());

        customException.setTimestamp(timestamp.toString());
        customException.setStatus(HttpStatus.BAD_REQUEST.value());
        customException.setError(HttpStatus.BAD_REQUEST.getReasonPhrase());
        customException.setMessage(message);
        customException.setPath(path);

        return customException;
    }

    private ProductException processCustomException(Exception e, String path) {

        ProductException customException = new ProductException();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());

        customException.setTimestamp(timestamp.toString());
        customException.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        customException.setError(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
        if (!StringUtils.isEmpty(e.getCause())) {
            customException.setMessage(e.getCause().getMessage());
        } else {
            customException.setMessage((e.getMessage()));
        }
        customException.setPath(path);

        return customException;
    }



}
