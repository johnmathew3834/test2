package org.lm.edh.api.product.model.entity;

public class AWProductRequest {

}
