package org.lm.edh.api.product.util;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;
import software.amazon.awssdk.services.secretsmanager.model.SecretsManagerException;

@Configuration
public class GetSecret {
    private static final Logger LOGGER = Logger.getLogger(GetSecret.class.getName());

    @Autowired
    private Environment environment;

    public Map<String, String> getSecretValue(String... keys) throws JSONException {
        Region region = Region.US_WEST_2;
        SecretsManagerClient secretsClient = SecretsManagerClient.builder()
                .region(region)
                .build();
        Map<String, String> secretMap = new HashMap<>();
        try {
            String secretJson = getValue(secretsClient, environment.getProperty(Constants.EDH_PRODUCT_API_SECRETS));
            parseJson(secretMap, secretJson, keys);
            secretsClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return secretMap;
    }

    private Map<String, String> parseJson(Map<String, String> secretMap, String json, String... keys) throws JSONException {
        JSONObject jObject = new JSONObject(json);
        
        	Stream.of(keys).forEach(key -> {        		
        	try {
				secretMap.put(key, jObject.getString(key));
			} catch (JSONException e) {
				e.printStackTrace();
	            LOGGER.error("Exception Occurred parsing Secrets Json :: ", e);
			}
        	});
			 
        return secretMap;
    }

    public static String getValue(SecretsManagerClient secretsClient, String secretName) {
        String secret = null;
        try {
            GetSecretValueRequest valueRequest = GetSecretValueRequest.builder()
                    .secretId(secretName)
                    .build();

            GetSecretValueResponse valueResponse = secretsClient.getSecretValue(valueRequest);
            secret = valueResponse.secretString();
        } catch (SecretsManagerException e) {
            System.err.println(e.awsErrorDetails().errorMessage());
        }
        return secret;
    }
}
