package org.lm.edh.api.product.model.entity;


import java.util.List;

/**
 * Created by vkalakotahe7160 on 11/1/2019
 */

public class APIResponse {

    private Pagination pagination;
    private List<Product> advisoryWorldAssets;

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public List<Product> getAdvisoryWorldAssets() {
        return advisoryWorldAssets;
    }

    public void setAdvisoryWorldAssets(List<Product> advisoryWorldAssets) {
        this.advisoryWorldAssets = advisoryWorldAssets;
    }
}
