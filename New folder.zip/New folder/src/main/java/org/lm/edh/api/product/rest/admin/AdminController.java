package org.lm.edh.api.product.rest.admin;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.apache.log4j.Category;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Created by vkalakotahe7160 on 11/1/2019
 */
@CrossOrigin(allowCredentials = "true")
@RestController
@RequestMapping("/products")
public class AdminController {

    private static final Logger LOGGER = Logger.getLogger(AdminController.class.getName());

    private JSONObject decodePayload(String awtAuthValue) throws JSONException {

        LOGGER.info(" Decoding AWT Token value :: " + awtAuthValue);
        DecodedJWT jwt = JWT.decode(awtAuthValue);
        String payload = jwt.getPayload();
        String decodedPayload = new String(Base64.decodeBase64(payload));
        return new JSONObject(decodedPayload);
    }

    private String applyLevel(Enumeration appLoggers, Level level, Logger root) {
        root.setLevel(level);
        while (appLoggers.hasMoreElements()) {
            Category tmpLogger = (Category) appLoggers.nextElement();
            tmpLogger.setLevel(level);
        }
        return "Log level " + level.toString() + " has been set";
    }

    @RequestMapping(value = "/admin/logger/level/{value}", method = RequestMethod.GET)
    @ResponseBody
    public String applyLogLevel(@PathVariable(value = "value") String loggerLevel) {

        Logger root = Logger.getRootLogger();
        Enumeration allLoggers = root.getLoggerRepository().getCurrentCategories();
        String returnString;
        if ("TRACE".equalsIgnoreCase(loggerLevel)) {
            returnString = applyLevel(allLoggers, Level.TRACE, root);
            LOGGER.trace(returnString);
        } else if ("DEBUG".equalsIgnoreCase(loggerLevel)) {
            returnString = applyLevel(allLoggers, Level.DEBUG, root);
            LOGGER.debug(returnString);
        } else if ("INFO".equalsIgnoreCase(loggerLevel)) {
            returnString = applyLevel(allLoggers, Level.INFO, root);
            LOGGER.info(returnString);
        } else if ("WARN".equalsIgnoreCase(loggerLevel)) {
            returnString = applyLevel(allLoggers, Level.WARN, root);
            LOGGER.warn(returnString);
        } else if ("ERROR".equalsIgnoreCase(loggerLevel)) {
            returnString = applyLevel(allLoggers, Level.ERROR, root);
            LOGGER.error(returnString);
        } else {
            returnString = "-- INVALID Logger Level -- Please use the valid value :: TRACE / INFO / WARN / ERROR.";
            LOGGER.warn(returnString);
        }

        return returnString;
    }

    @RequestMapping(value = "/admin/headers", method = RequestMethod.GET, produces = "application/json")
    public List<AdminController.Header> invokeHeaders(HttpServletRequest request) {
        LOGGER.debug("invokeHeaders endpoint has been executed");
        List<AdminController.Header> lstHeaders = new ArrayList<AdminController.Header>();
        Enumeration<String> headerNames = request.getHeaderNames();
        LOGGER.debug("****************START**************************");
        while (headerNames.hasMoreElements()) {
            AdminController.Header headerObj = new AdminController.Header();
            String headerName = headerNames.nextElement();
            headerObj.setHeader(headerName);
            LOGGER.debug("headerName:: " + headerName);

            Enumeration<String> headers = request.getHeaders(headerName);
            while (headers.hasMoreElements()) {
                String headerValue = headers.nextElement();
                LOGGER.debug("value:: " + headerValue);
                headerObj.setValue(headerValue);
            }
            lstHeaders.add(headerObj);
        }
        LOGGER.debug("********************END **********************");

        return lstHeaders;
    }

    private class Header {
        private String header;
        private String value;

        public String getHeader() {
            return header;
        }

        public void setHeader(String header) {
            this.header = header;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }


}
