node {
    stage('Preparation') { // for display purposes
        // Get EDM code from a GitHub repository
        cleanWs()
        checkout scm
        sh "python $WORKSPACE/deployment_scripts/replace_tokens.py --localFolder $WORKSPACE --env dev"
    }
    stage('Build') {
        // Run the maven build
        sh "chmod 775 $WORKSPACE/deployment_scripts/build.sh"
        sh "$WORKSPACE/deployment_scripts/build.sh $WORKSPACE dev"
    }
    stage('Deploy') {
        //Run the deployment script
        sh "python $WORKSPACE/deployment_scripts/edm_deploy.py $WORKSPACE lm-edm-builds-ndev ${env.BUILD_NUMBER} dev $WORKSPACE/deployment_scripts/config.json"
    }
}