workspace=$1
env=$2

echo "Building Backend Code"
mvn clean -Djasypt.encryptor.password={{PRODUCT-API-ENCRYPTION-KEY}} package clean install -f $WORKSPACE/pom.xml -DskipTests=true

status=$?
if [ $status -ne 0 ]
then
   echo "Backend Build Failed"
   exit 1
fi