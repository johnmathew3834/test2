import ConfigParser
import StringIO
import datetime
import glob
import logging as log
import os
import sys
import time
from shutil import copy, copytree
import boto3
import json

# Set Logging
logger = log.getLogger()
logger.setLevel(log.INFO)


def copy_dirs_to_target(local_folder):
    log.info("Main Build Folder is " + local_folder)
    # Define paths
    target = local_folder + "/target"
    target_lib_dir = target + "/lib"
    target_scripts_dir = target + "/scripts"
    target_config_dir = target + "/config"

    # Create target lib directory if it does not exist
    if not os.path.exists(target_lib_dir):
        os.mkdir(target_lib_dir)
    if not os.path.exists(target_scripts_dir):
        os.mkdir(target_scripts_dir)
    if not os.path.exists(target_config_dir):
        os.mkdir(target_config_dir)
    '''
    if not os.path.exists(target_ui_dir):
        os.mkdir(target_ui_dir)
'''
    # Copy jars into lib folder
    for jar in glob.glob(local_folder + "/target/*.jar"):
        log.info('jar file is ' + jar)
        copy(jar, target_lib_dir)
        log.info("Jar files copied to " + target_lib_dir)

    # Copy scripts into scripts directory
    for sh in glob.glob(local_folder + "/scripts/*.sh"):
        copy(sh, target_scripts_dir)

    # Copy property files in config directory
    for config in glob.glob(local_folder + "/src/main/resources/*.properties"):
        copy(config, target_config_dir)


def copy_to_s3(local_folder, s3_bucket, build_number, environment):
    """

    :param local_folder:
    :param s3_bucket:
    :param build_number:
    :param environment:
    :return:
    """
    log.info("S3 Bucket for Builds is " + s3_bucket)
    date_timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d-%H:%M:%S')

    local_folder_target = local_folder + "/target"
    s3_path = "edh-product-api/builds/" + build_number

    s3 = get_client(environment, 's3')


    for folder in ["lib", "scripts", "config"]:
        for root, dirs, files in os.walk(local_folder_target + "/" + folder):
            for filename in files:
                # construct full local path
                local_path = os.path.join(root, filename)
                relative_path = os.path.relpath(local_path, local_folder_target).replace("\\", "/")
                s3_path_new = os.path.join(s3_path, relative_path).replace("\\", "/")

                s3.upload_file(local_path, s3_bucket, s3_path_new,
                                           ExtraArgs={'ServerSideEncryption': "AES256"})

    log.info("Build copied to S3 " + s3_path)

    # Clean-up contents of Latest folder
    cleanup_s3(s3_bucket_name, "edh-product-api/latest/", environment)
    s3_path = "edh-product-api/latest"

    # Copying to Latest folder
    for folder in ["lib", "scripts", "config"]:
        for root, dirs, files in os.walk(local_folder_target + "/" + folder):
            for filename in files:
                # construct full local path
                local_path = os.path.join(root, filename)
                relative_path = os.path.relpath(local_path, local_folder_target).replace("\\", "/")
                s3_path_new = os.path.join(s3_path, relative_path).replace("\\", "/")

                s3.upload_file(local_path, s3_bucket, s3_path_new,
                                           ExtraArgs={'ServerSideEncryption': "AES256"})

    s3.put_object(Bucket=s3_bucket, Key='edh-product-api/latest/Build_ID-' + build_number + '.txt',  ServerSideEncryption='AES256')

    log.info("Build copied to S3 " + s3_path)


# Returns S3 client by reading access key and secret keys based on the environment
def get_client(environment, client_type):
    environment_file_path = "/var/lib/jenkins/.edm/" + environment + ".properties"

    config = StringIO.StringIO()
    config.write('[dummysection]\n')
    config.write(open(environment_file_path).read())
    config.seek(0, os.SEEK_SET)

    cp = ConfigParser.ConfigParser()
    cp.readfp(config)

    session = boto3.session.Session(cp.get('dummysection', 'aws_access_key_id'),
                                    cp.get('dummysection', 'aws_secret_access_key'))

    access_key = cp.get('dummysection', 'aws_access_key_id')
    secret_key = cp.get('dummysection', 'aws_secret_access_key')

    #client = session.resource(client_type)
    # Do not hard code credentials
    '''
    if [ client_type == 's3' ]:
        client = boto3.client(
            client_type,aws_access_key_id=access_key,aws_secret_access_key=secret_key,
        )
    else:
    '''
    client = boto3.client(
            client_type,aws_access_key_id=access_key,aws_secret_access_key=secret_key,region_name= 'us-east-1'
        )

    return client


"""
Used to clean up S3 bucket based on given prefix
"""
def cleanup_s3(s3_bucket, prefix, environment):
    s3 = get_client(environment, 's3')

    while True:
        objects_to_delete = s3.list_objects(Bucket=s3_bucket, Prefix=prefix)
        delete_keys = {'Objects': [{'Key': k} for k in [obj['Key'] for obj in objects_to_delete.get('Contents', [])]]}
        print 'Size of Objects is ' + str(len(delete_keys['Objects']))
        if (len(delete_keys['Objects']) > 0):
            s3.delete_objects(Bucket=s3_bucket, Delete=delete_keys)

        if len(delete_keys['Objects']) == 0:
            break

    log.info("Bucket " + s3_bucket + prefix + " folder cleaned up")

def deploy_to_ec2(environment,config,deployment_type):
    ssm_client = get_client(environment,'ssm')
    instance_Ids_api = config['instanceIDs'][environment][deployment_type]
    command = config['commands'][deployment_type]

    response = ssm_client.send_command(
        InstanceIds=instance_Ids_api,
        DocumentName="AWS-RunShellScript",
        Parameters={'commands': command},
        CloudWatchOutputConfig={
            'CloudWatchLogGroupName': 'edh-api-product-deployment',
            'CloudWatchOutputEnabled': True
        }
    )
    print(response)

    '''
    command_id = response['Command']['CommandId']
    output = ssm_client.get_command_invocation(
        CommandId=command_id,
        InstanceId='i-0328022acd1f9aac2',
    )
    print(output)
    '''

def read_config(file_location):
    with open(file_location) as json_file:
        data = json.load(json_file)
    return data

if __name__ == "__main__":
    if sys.argv.__len__() != 6:
        log.error("Incorrect Arguments Passed")
        sys.exit(1)

    local_folder, s3_bucket_name, build_number, environment, config_file = sys.argv[1:6]
    copy_dirs_to_target(local_folder)
    copy_to_s3(local_folder, s3_bucket_name, build_number, environment)

    config = read_config(config_file)
    deploy_to_ec2(environment, config, 'api')