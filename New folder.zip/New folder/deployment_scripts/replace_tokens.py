import argparse
import base64
import json
import logging as log
import os
import traceback
import StringIO
import ConfigParser

import boto3

# Set Logging
logger = log.getLogger()
logger.setLevel(log.INFO)
parser = argparse.ArgumentParser()

# Create a Secrets Manager client
session = boto3.session.Session()

def get_client(environment):

    environment_file_path = "/var/lib/jenkins/.edm/" + environment + ".properties"

    config = StringIO.StringIO()
    config.write('[dummysection]\n')
    config.write(open(environment_file_path).read())
    config.seek(0, os.SEEK_SET)

    cp = ConfigParser.ConfigParser()
    cp.readfp(config)

    # Create a Secrets Manager client
    session = boto3.session.Session()
    region_name = "us-east-1"

    client = session.client(
    service_name='secretsmanager',
    region_name=region_name,
    aws_access_key_id=cp.get('dummysection', 'aws_access_key_id'),
    aws_secret_access_key=cp.get('dummysection', 'aws_secret_access_key')
    )

    return client

def get_secrets(secret_name, env):
    '''
    Get secret value based on a secret name
    :param secret_name:
    :return: secret value
    '''
    try:
        client = get_client(env)
        get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
        )

    except Exception as e:
        traceback.print_exc()
        raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = json.loads(get_secret_value_response['SecretString'])
            return secret
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def get_files_list():
    '''
    Get a list of all relevent files from root directory
    :return: files list
    '''
    filenames = []
    #Create a list of all property files
    for root, directories, files in os.walk(args.localFolder):
        for f in files:
            if f.endswith(('.properties', '.sh', '.json')):
                filenames.append(os.path.join(root,f))

    log.info("Total Files " + str(filenames.__len__()))
    return filenames

def replace_tokens(filenames, secrets):
    '''
    Replaces token values from secret manager
    :param filenames: file names to process
    :param list: list of all keys in secret manager
    :return:
    '''
    for file in filenames:
        input = open(file).read()
        for i in secrets:
            log.info(i)
            if input.__contains__('{{' + i):
                input = input.replace('{{' + i.upper() + '}}', secrets[i])
        output = open(file, 'w')
        output.write(input)
        output.close()

    log.info("Tokens replaced in files")


if __name__ == "__main__":
    parser.add_argument("--localFolder", help="Local Workspace Folder", required = "true")
    parser.add_argument("--env", help = "Environment for which tokens need to be replaced. Values - dev, qa, uat, prod", required = "true")
    args = parser.parse_args()

    '''Get list of all key value pair secrets for the app'''
    secrets = get_secrets("EDH-PRODUCT-SERVICE", args.env)
    '''Get list of all property files where secrets need to be replaced'''
    filenames = get_files_list();
    '''Replace values in these files'''
    replace_tokens(filenames, secrets)

