kill $(cat /opt/edmapp/ProductAPI/pid.file)
