check_status()
{
    status=$1
    message=$2
    if [ $status -ne 0 ]
    then
        echo "Error occurred in $message. Exiting"
        exit 1
    else
        echo "$message success"
    fi
}

deploy_api()
{

    #sudo su svc-edm-app-user
    sudo su - svc-edm-app-user
    check_status $? "sudo to edm app user"

    cd /opt/edmapp/ProductAPI/

    rm -rf config lib scripts
    check_status $? "remove directories"

    aws s3 sync s3://{{PRODUCT-API-BUILDS-BUCKET}}/edh-product-api/latest/ /opt/edmapp/ProductAPI/
    check_status $? "copy build artifacts"

    sudo chown -R svc-edm-app-user. /opt/edmapp/ProductAPI/

    sudo chmod 755 /opt/edmapp/ProductAPI/scripts/*.sh
    check_status $? "Updated shell script permissions to 755"

    cd /opt/edmapp/ProductAPI/scripts

    ./stop.sh
    check_status $? "stop current process"

    ./start.sh
    check_status $? "start new process"

    echo "Backend Build Deployed"

}

deploy_ui()
{
    sudo su - svc-edm-app-user
    check_status $? "sudo to edm app user"

    cd /opt/edmapp/ProductAPI/html

    rm -rf /opt/edmapp/ProductAPI/html/*
    check_status $? "remove directories"

    aws s3 sync s3://{{PRODUCT-API-BUILDS-BUCKET}}/edh-product-api/latest/ /opt/edmapp/ProductAPI/html/
    check_status $? "copy build artifacts"

    echo "UI Build Deployed"
}

deployment_type=$1

if [ "$deployment_type" == "ui" ]; then
    deploy_ui
elif [ "$deployment_type" == "api" ]; then
    deploy_api
fi


