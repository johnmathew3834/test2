package com.leggmason.edm.ds.solution.drivers

import com.leggmason.edm.ds.framework.context.SparkSessionProvider;
import com.leggmason.edm.ds.framework.driver.BaseDriver;
import com.leggmason.edm.ds.solution.servicesImpl.CountryServiceImpl

object CountryDriver extends BaseDriver with SparkSessionProvider{
  def main(args: Array[String]): Unit = {
    initilize(getSparkSession(this.getClass, args),args)
    new CountryServiceImpl(spark,source).doService();
  }
}