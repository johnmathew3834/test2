package com.leggmason.edm.ds.framework.common.constant

object PropertyFileConstant {
  val CDC_JSON_MAPPING="/CDCMapping.json";
}