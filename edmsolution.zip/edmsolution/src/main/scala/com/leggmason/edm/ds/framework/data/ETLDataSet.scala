package com.leggmason.edm.ds.framework.data

import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.DataFrame


class ETLDataSet {
  var rddmap = scala.collection.mutable.Map[String, RDD[_]]() 
  var dataframeMap = scala.collection.mutable.Map[String, DataFrame]() 
  var rddmapList = scala.collection.mutable.Map[String, List[RDD[_]]]() 
  var dataframeMapList = scala.collection.mutable.Map[String, List[DataFrame]]()
  var datasetMap = scala.collection.mutable.Map[String, Dataset[_]]()
  var dataTypeMap = scala.collection.mutable.Map[String, ECLDataType]()
}