package com.leggmason.edm.ds.framework.context

import org.apache.spark.sql.SparkSession;

trait SparkSessionProvider extends SparkSessionAware {
  override def getSparkSession(clazz: Class[_], args: Array[String]):SparkSession = {
    if(sparkSession == null)
    sparkSession = SparkSession.builder().appName(this.getClass().getName().dropRight(1)).getOrCreate();
    sparkSession;
  }
}