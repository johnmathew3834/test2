package com.leggmason.edm.ds.framework.common.constant

object AWSConstant {
  val credentialsURL = "http://169.254.169.254/latest/meta-data/iam/security-credentials/"
}