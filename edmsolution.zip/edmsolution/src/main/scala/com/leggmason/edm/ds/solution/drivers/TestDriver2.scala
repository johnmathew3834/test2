package com.leggmason.edm.ds.solution.drivers

import com.leggmason.edm.ds.framework.context.SparkSessionProvider;
import com.leggmason.edm.ds.framework.driver.BaseDriver;

object TestDriver2 extends BaseDriver with SparkSessionProvider {
def main(args: Array[String]): Unit = {
 // val sparks = getSparkSession(this.getClass,args);
  initilize(getSparkSession(this.getClass,args),args);
    /*spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", "AKIAI6PHGUVBDF4DUUTA")
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey", "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");
    spark.sparkContext.hadoopConfiguration.set("fs.s3n.impl","org.apache.hadoop.fs.s3native.NativeS3FileSystem")*/
    val csvRDD = spark.read.option("header","true").csv("s3n://genpact-es-poc/Input/bi_salesFact.csv");
    csvRDD.write.mode("overwrite").csv("s3n://genpact-es-poc/output2/")
}
}