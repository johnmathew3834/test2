package com.leggmason.edm.ds.framework.common.utils

import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.auth.InstanceProfileCredentialsProvider
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.AmazonS3Exception
import com.amazonaws.services.s3.model.CopyObjectRequest
import com.amazonaws.services.s3.model.DeleteObjectsRequest
import com.amazonaws.services.s3.model.DeleteObjectsRequest.KeyVersion
import com.amazonaws.services.s3.model.ListObjectsRequest
import com.amazonaws.services.s3.model.ObjectMetadata
import com.amazonaws.services.s3.model.PutObjectRequest
import com.amazonaws.services.s3.model.PutObjectResult
import org.slf4j.LoggerFactory


object S3Util {
  
  private val logger = LoggerFactory.getLogger(this.getClass);
  
  private val S3 = "s3://"
  
  /**
   * @param path s3 path
   * @return bucket name
   */
  def getBucketFromPath(path: String): String = {
    logger.info("getBucketFromPath start")
    if (path == null) {
      throw new IllegalArgumentException("Path Should not be null");
    }
    val finalPath: String = path.replace(S3, "")
    logger.info("getBucketFromPath done")
    return finalPath.split(("/"))(0)
  }
  
  /**
   * @param path s3 path
   * @return key name
   */
  def getKeyFromPath(path: String): String = {
    logger.info("getKeyFromPath start")
    if (path == null) {
      throw new IllegalArgumentException("Path Should not be null");
    }
    val finalPath: String = path.replace(S3, "")
    val spliResult = finalPath.split(("/"))
    val slicedResult = spliResult.slice(1, spliResult.length + 1)
    logger.info("getKeyFromPath done")
    return slicedResult.mkString("/")
  }
}