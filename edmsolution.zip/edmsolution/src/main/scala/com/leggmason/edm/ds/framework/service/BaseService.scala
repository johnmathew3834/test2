package com.leggmason.edm.ds.framework.service

import com.leggmason.edm.ds.framework.data.ETLDataSet

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Row;

trait BaseService {
   def doService() : Unit = {
        extract(_:SparkSession,_:String,_:String,_:ETLDataSet)
        clean(_:RDD[Array[String]]):RDD[(String, String)];
        load(_:RDD[_],_:String,_:String,_:ETLDataSet);
  }

  def extract(spark: SparkSession,path:String,sourceType:String,etlDataSet:ETLDataSet):List[_]
  def clean(rdd:RDD[Array[String]]):RDD[(String, String)];
  def load(rdd:RDD[_],path:String,sourceType:String,etlDataSet:ETLDataSet)  
  
}