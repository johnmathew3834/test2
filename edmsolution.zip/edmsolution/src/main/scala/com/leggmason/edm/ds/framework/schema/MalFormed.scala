package com.leggmason.edm.ds.framework.schema

import org.apache.spark.sql.types.{StructType, StructField, StringType};

object MalFormed {
  val schema=StructType(Seq(StructField("error", StringType, true)));
}