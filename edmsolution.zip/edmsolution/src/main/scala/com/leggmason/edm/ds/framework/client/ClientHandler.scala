package com.leggmason.edm.ds.framework.client

trait ClientHandler {
    def getListOfFiles(path:String):List[String];
}