package com.leggmason.edm.ds.framework.common.utils

object PropertyTest {
  def main(args: Array[String]): Unit = {
    PropertyUtil.loadProperties("country", args(0));
    println(PropertyUtil.propertyMap("country").getProperty("sourcelocation"));
    println(PropertyUtil.propertyMap("country").getProperty("delimiter"));
  }
}