package com.leggmason.edm.ds.framework.common.utils

import com.leggmason.edm.ds.framework.common.constant._;
import com.leggmason.edm.ds.framework.schema._;

object Test {
  def main(args: Array[String]): Unit = {
   // println(JsonUtil.convertJsonToMap("""{"name":"john", "age": 28}"""));
   // println(JsonUtil.toMap("""{"name":"john", "age": 29}"""));
    println(JsonUtil.convertJsonToMap(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING)));
   // println(JsonUtil.convertJsonToMapWithValInt(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING)));
    //println(JsonUtil.convertJsonToMapWithValInt(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING))(("Zip")));
    println(JsonUtil.convertJsonToObject("/Country.json",new SchemaMapper().getClass).asInstanceOf[SchemaMapper].getObjectName);
  println(JsonUtil.convertJsonToObject("/Country.json",new SchemaMapper().getClass).asInstanceOf[SchemaMapper].getSchema().get(1).getPosition);
  println(JsonUtil.convertJsonToObject("/Country.json",new SchemaMapper().getClass).asInstanceOf[SchemaMapper].getSchema().get(0).getColumnName)
  }
}