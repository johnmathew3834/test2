package com.leggmason.edm.ds.framework.schema

  case class SchemaRemove(var columnName:String,var dataType:String,var maxLength:Int,var mandatory:Boolean,var validationRequired:Boolean)
  class ParentSchema(var objectName:String,var objectDescription:String,var schema: List[SchemaRemove]){
  def this(){
      this(null,null,null);
    } 
  }
  /*case class SchemaMapper(var parentSchema:ParentSchema){
    def this(){
      this(null);
    }   */
    
