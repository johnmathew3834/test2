package com.leggmason.edm.ds.framework.context

import org.apache.spark.sql.SparkSession;

trait SparkSessionAware {
  private[context] var sparkSession: SparkSession = null;

  def getSparkSession(clazz: Class[_], args: Array[String]) = sparkSession;
}