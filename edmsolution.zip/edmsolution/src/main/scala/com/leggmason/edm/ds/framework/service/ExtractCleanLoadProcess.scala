package com.leggmason.edm.ds.framework.service

import com.leggmason.edm.ds.framework.client.ClientFactory
import com.leggmason.edm.ds.framework.common.utils.JsonUtil
import com.leggmason.edm.ds.framework.common.constant.PropertyFileConstant
import com.leggmason.edm.ds.framework.common.utils.FileUtil
import com.leggmason.edm.ds.framework.common.utils.DataFrameUtil
import com.leggmason.edm.ds.framework.data.ETLDataSet
import com.leggmason.edm.ds.framework.data.ECLDataType

import org.slf4j.LoggerFactory


import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset;
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ListBuffer

trait ExtractCleanLoadProcess extends BaseService {
  
  val logger = LoggerFactory.getLogger(this.getClass)
  override def extract(spark: SparkSession,path:String,sourceType:String,etlDataSet:ETLDataSet): List[_] = {
    val client = ClientFactory.getClient("S3Client");
    val dataFrameList:ListBuffer[DataFrame] = ListBuffer();
    val rddList:ListBuffer[RDD[_]] = ListBuffer();
    val files : List[String] = client.getListOfFiles(path);
    
    logger.info("files....."+files)
     for(file:String <- files){ 
    if(etlDataSet.dataTypeMap(sourceType).sourceFileType=="text"){
      rddList +=spark.sparkContext.textFile(path);
    } else {
       val eclDataType:ECLDataType = etlDataSet.dataTypeMap(sourceType);
      dataFrameList += DataFrameUtil.buildDatFrame(spark, file, eclDataType);
       
     
    }
     }
    
    
    if(etlDataSet.dataTypeMap(sourceType).sourceFileType=="text"){
      etlDataSet.rddmapList += (sourceType -> rddList.toList);
      etlDataSet.rddmapList(sourceType);
    } else{
      etlDataSet.dataframeMapList += (sourceType -> dataFrameList.toList);
      etlDataSet.dataframeMapList(sourceType);
    }
   
    
    
  }
  
  def load(rdd:RDD[_],path:String,sourceType:String,etlDataSet:ETLDataSet){
    
  }

}