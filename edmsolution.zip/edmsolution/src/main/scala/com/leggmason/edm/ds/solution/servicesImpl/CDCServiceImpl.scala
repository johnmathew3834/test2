package com.leggmason.edm.ds.solution.servicesImpl

import com.leggmason.edm.ds.framework.service.ExtractCleanLoadProcess
import com.leggmason.edm.ds.solution.services.CDCService
import com.leggmason.edm.ds.framework.data.ETLDataSet
import com.leggmason.edm.ds.framework.data.ECLDataType
import com.leggmason.edm.ds.framework.common.utils.JsonUtil
import com.leggmason.edm.ds.framework.common.constant.PropertyFileConstant
import com.leggmason.edm.ds.framework.common.utils.FileUtil
import com.leggmason.edm.ds.framework.schema.MalFormed

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Row;


class CDCServiceImpl(spark: SparkSession) extends CDCService with Serializable {
  
 
 /* override def doService(): Unit = {
    val dataset = new ETLDataSet();
    val eclDataType = new ECLDataType();
    dataset.dataTypeMap += ("CDCSource" -> eclDataType);
    logger.info("Im entering do service");
    val dataFrameList: List[DataFrame] = extract(spark, "s3://genpact-es-poc/Inputt/", "CDCSource", dataset).asInstanceOf[List[DataFrame]];
    val dataFrame = dataFrameList(0);
    val schema = dataFrame.schema

    val processedData = clean(dataFrame);

    val invalidRow = processedData.filter(_._2.length > 1).map(x => Row(x._1.mkString(",").concat(x._2)));
    val validRecord = processedData.filter(_._2.length == 0).map(x => (x._1));

    spark.createDataFrame(validRecord, schema).write.mode("overwrite").csv("s3://genpact-es-poc/output3/");
    spark.createDataFrame(invalidRow, MalFormed.schema).write.mode("overwrite").csv("s3://genpact-es-poc/output4/")

  }

  override def clean(dataFrame: DataFrame): RDD[(Row, String)] = {
    val jsonMap = JsonUtil.convertJsonToMapWithValInt(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING));
    dataFrame.rdd.mapPartitions(rows=>processData(rows, jsonMap), true);
  }

  def processData(rowIterator: Iterator[org.apache.spark.sql.Row], jsonMap: Map[String, Int]): Iterator[(Row, String)] = {
    // import spark.implicits._
    var collect: StringBuilder = null;
    val row = rowIterator.map { row =>
      collect = new StringBuilder();
      if (row.getInt(jsonMap("Zip")) == 29526) {
        collect.append("|zipCode is wrong");
      }

      (row, collect.toString());
    }
    row;

  }*/
  
  override def clean(rdd: RDD[Array[String]]): RDD[(String, String)] = {
    null;
  }

}