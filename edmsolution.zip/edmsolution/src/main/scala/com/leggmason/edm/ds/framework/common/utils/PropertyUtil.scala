package com.leggmason.edm.ds.framework.common.utils

import java.io.File
import java.io.FileNotFoundException
import java.io.FileReader
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties
import scala.io.Source
import org.slf4j.LoggerFactory
object PropertyUtil {
  
  val logger = LoggerFactory.getLogger(this.getClass)
  val propertyMap = scala.collection.mutable.Map[String,Properties]();

  def loadProperties(key: String, propertyFile: String): Unit  = synchronized {
    logger.info("Begin getProperties"+propertyFile);

	try {
    var properties = new Properties();
      properties.load(getClass.getResourceAsStream(propertyFile))
      propertyMap += (key -> properties)
    }catch {
      case e:Exception=> e.printStackTrace();
    }
    logger.info("End getProperties");
  }
  
  
}