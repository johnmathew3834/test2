package com.leggmason.edm.ds.framework.client

object LocalClient extends ClientHandler {  
  override def getListOfFiles(path:String):List[String]={ null;}
}