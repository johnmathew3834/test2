package com.leggmason.edm.ds.framework.validation

import org.joda.time.format._

object DateValidation extends BaseValidator {

  val defaultDatePattern = "dd/MM/yyyy";
  def isValidDate(date: String): Boolean = {
    try {
      val fmt = DateTimeFormat forPattern "dd/MM/yyyy";
      Some(fmt parseDateTime date);
      true;
    } catch {
      case e: IllegalArgumentException => false
      case e: Exception                => false
    }
  }

}