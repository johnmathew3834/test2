package com.leggmason.edm.ds.solution.servicesImpl

import com.leggmason.edm.ds.solution.services.CountryService
import com.leggmason.edm.ds.framework.service.ExtractCleanLoadProcess
import com.leggmason.edm.ds.framework.data.ETLDataSet
import com.leggmason.edm.ds.framework.data.ECLDataType
import com.leggmason.edm.ds.framework.common.utils.JsonUtil
import com.leggmason.edm.ds.framework.common.constant.PropertyFileConstant
import com.leggmason.edm.ds.framework.common.utils.PropertyUtil
import com.leggmason.edm.ds.framework.common.utils.FileUtil
import com.leggmason.edm.ds.framework.schema.MalFormed
import com.leggmason.edm.ds.framework.schema.SchemaMapper
import com.leggmason.edm.ds.framework.schema.Schema

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Row;
import scala.collection.JavaConversions._
import com.leggmason.edm.ds.framework.validation.CommonValidator

class CountryServiceImpl(spark: SparkSession,source:String) extends CountryService with Serializable {
  override def doService(): Unit = {
    val dataset = new ETLDataSet();
    val eclDataType = new ECLDataType();
    val sourceProperty=PropertyUtil.propertyMap(source);
    eclDataType.schema=JsonUtil.convertJsonToObject("/Country.json",new SchemaMapper().getClass).asInstanceOf[SchemaMapper];
    eclDataType.sourceFileType=sourceProperty.getProperty("fileType");
    dataset.dataTypeMap += (source -> eclDataType);
    val rddList: List[RDD[String]] = extract(spark, sourceProperty.getProperty("sourcelocation"), source, dataset).asInstanceOf[List[RDD[String]]];
    val rdd = rddList(0);
    
    val splitRddByDelimiter = rdd.map(row=>row.split(sourceProperty.getProperty("delimiter")))

    val processedData = clean(splitRddByDelimiter);

    val invalidRow = processedData.filter(_._2.length > 1).map(x => Row(x._1.mkString(",").concat(x._2)));
    val validRecord = processedData.filter(_._2.length == 0).map(x => (x._1));
    
    
    
    invalidRow.saveAsTextFile(sourceProperty.getProperty("destinationmalformedlocation"));
    validRecord.saveAsTextFile(sourceProperty.getProperty("destinationprocessedlocation"));
    //spark.createDataFrame(validRecord, schema).write.mode("overwrite").csv(sourceProperty.getProperty("sourcelocation"));
    //spark.createDataFrame(invalidRow, MalFormed.schema).write.mode("overwrite").csv(sourceProperty.getProperty("sourcelocation"))

  }

  override def clean(rdd: RDD[Array[String]]): RDD[(String, String)] = {
    val jsonMap = JsonUtil.convertJsonToMapWithValInt(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING));
      rdd.mapPartitions(rows=>processData(rows, jsonMap), true);
  }

  def processData(rowIterator: Iterator[Array[String]], jsonMap: Map[String, Int]): Iterator[(String, String)] = {
    // import spark.implicits._
    var collect: StringBuilder = null;
    val schemaMapper=JsonUtil.convertJsonToObject("/Country.json",new SchemaMapper().getClass).asInstanceOf[SchemaMapper];
    collect = new StringBuilder();
    val row = rowIterator.map { row =>
      collect.clear()
      for(schema <- schemaMapper.getSchema()){
        
        if(schema.getValidationRequired && schema.getMandatory){
          if(CommonValidator.isEmpty(row((schema.getPosition)-1))){
             collect.append("|"+schema.getColumnName+" Should not be empty");
          }
        }
      }
      
     /* if (row.getInt(jsonMap("Zip")) == 29526) {
        collect.append("|zipCode is wrong");
      }*/

      (row.mkString, collect.toString());
    }
    row;

  }
}