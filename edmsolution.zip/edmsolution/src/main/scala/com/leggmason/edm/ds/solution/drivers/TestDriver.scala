package com.leggmason.edm.ds.solution.drivers

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object TestDriver {
  def main(args: Array[String]): Unit = {
    val sparkConf =  new SparkConf().setAppName("testSuresh");
    val sparkContext = new SparkContext(sparkConf);
    sparkContext.hadoopConfiguration.set("fs.s3n.awsAccessKeyId", "AKIAI6PHGUVBDF4DUUTA")
    sparkContext.hadoopConfiguration.set("fs.s3n.awsSecretAccessKey", "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");
    sparkContext.hadoopConfiguration.set("fs.s3n.impl","org.apache.hadoop.fs.s3native.NativeS3FileSystem")
    val fileRdd = sparkContext.textFile("D:\\data\\input\\");
    val pairRdd = fileRdd.flatMap(record => record.split(",")).map(word=>(word,1));
    val reducedData=pairRdd.reduceByKey(_+_);
    reducedData.saveAsTextFile("s3n://genpact-es-poc/outputt/");
    //reducedData.saveAsTextFile("D:\\data\\output\\");
    //pairRdd.collect();
    
  }
}