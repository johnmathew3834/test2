package com.leggmason.edm.ds.solution.services

import com.leggmason.edm.ds.framework.service.ExtractCleanLoadProcess

trait CDCService extends ExtractCleanLoadProcess {
  //def validatePhone();
  
}