package com.leggmason.edm.ds.framework.client

object Test {
  def main(args: Array[String]): Unit = {
    println(ClientFactory.getClient("S3Client").getListOfFiles("s3://genpact-es-poc/Inputt/"));
    //getListOfFiles
  }
}