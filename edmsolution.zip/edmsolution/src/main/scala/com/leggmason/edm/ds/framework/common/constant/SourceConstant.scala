package com.leggmason.edm.ds.framework.common.constant

object SourceConstant {
  val CDC_SOURCE="CDC";
}