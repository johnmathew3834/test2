package com.leggmason.edm.ds.framework.validation

trait BaseValidator {
}