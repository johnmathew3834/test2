package com.leggmason.edm.ds.framework.data

import com.leggmason.edm.ds.framework.common.constant.DataFrameConstant;

import java.util.Properties

import org.apache.spark.sql.types.StructType;
import com.leggmason.edm.ds.framework.schema.SchemaMapper
import com.leggmason.edm.ds.framework.common.utils._


class ECLDataType {
  var appendMode:String=DataFrameConstant.overwrite;
  var inferschema:Boolean=DataFrameConstant.inferSchema;
  var destinationFileType:String=DataFrameConstant.csv;
  var sourceFileType:String=DataFrameConstant.csv;
  var header:Boolean=true;
  var library:String="";
  var customSchema:StructType=null;
  var schema:SchemaMapper=null;
  
  def load(sourceProperty:Properties){
   //sourceFileType=sourceProperty.getProperty("");
   // inferschema=sourceProperty.getProperty("").asInstanceOf[Boolean];
    destinationFileType=sourceProperty.getProperty("fileType");
    sourceFileType=sourceProperty.getProperty("fileType");
    schema=JsonUtil.convertJsonToObject(sourceProperty.getProperty("schemeLocation"),new SchemaMapper().getClass).asInstanceOf[SchemaMapper];
  }
}