package com.leggmason.edm.ds.framework.common.utils

import scala.io.Source._;
import java.util.Properties;

object ConfUtil {
  
  val propMap = scala.collection.mutable.Map[String,Properties]();
  
   
     def getProp(prop:String) : Properties = {
       if(propMap.get(prop) == null) {
         load(prop);
       }
       propMap.getOrElse(prop,null);
     }
     
     
     def load(prop:String){
       var properties : Properties = null
       val url = getClass.getResource("conf/fp.properties"); 
       if(url != null){
         val reader = fromURL(getClass.getResource("conf/fp.properties")).bufferedReader();
          properties = new Properties()
          properties.load(reader)
       }
       propMap.put(prop,properties);
     }
  
}