package com.leggmason.edm.ds.framework.client

import com.leggmason.edm.ds.framework.common.constant.AWSConstant
import scala.io.Source
import java.io.File
import org.slf4j.LoggerFactory
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.auth.InstanceProfileCredentialsProvider
import com.leggmason.edm.ds.framework.common.utils.S3Util
import com.amazonaws.services.s3.model.ListObjectsRequest
import scala.collection.mutable.ListBuffer
import com.amazonaws.services.s3.model.S3ObjectSummary


object S3Client extends ClientHandler {
  private var basicAWSCredentials: BasicAWSCredentials = null
  private var s3Client: AmazonS3Client = null
  private val S3 = "s3://"
  
  val logger = LoggerFactory.getLogger(this.getClass)
  var isEMRClusterCheckDone = false
  var isEMRClusterCached = false
  val emrCheckLock = new Object()
  val CLUSTER_DETAIL_FILE = "/mnt/var/lib/info/job-flow.json"
 

  /**
   * @return true/false
   */
  def isEMRCluster(): Boolean = {
    emrCheckLock.synchronized {
      if (!isEMRClusterCheckDone) {
        logger.info("isEMRCluster start")
        var role: String = null
        var isCluster: Boolean = false
        try {
          role = Source.fromURL(AWSConstant.credentialsURL).toString()
          isCluster = new File(CLUSTER_DETAIL_FILE).exists          
          isEMRClusterCached = (role != null && isCluster)
        } catch {
          // Following catch will determine that it is a local system not EMR/EC2
          case (conn: java.net.ConnectException) => {}
          case (err: Exception) => {
            logger.error(err.getMessage)
            //throw err
          }
        }
        isEMRClusterCheckDone = true
        logger.info("isEMRCluster done")
      }
      return isEMRClusterCached
    }
  }  
    def connectS3FromLocal(basicAWSCredentials: BasicAWSCredentials) = {
    logger.info("connectToS3 start")
    if (basicAWSCredentials == null) {
      throw new IllegalArgumentException("Basic credentials should not be null.");
    }
    try {
      this.basicAWSCredentials = basicAWSCredentials
      s3Client = new AmazonS3Client(basicAWSCredentials)
    } catch {
      case (err: Error) => {
        this.basicAWSCredentials = null; s3Client = null;
        logger.error(err.getMessage); throw err
      }
    }
    logger.info("connectToS3 done")
  }

  /**
   * Creates AWS S3 Client object
   */
  def connectS3FromEMR() = {
    logger.info("connectToS3 start")
    try {
      s3Client = new AmazonS3Client(new InstanceProfileCredentialsProvider())
    } catch {
      case (err: Error) => {
        this.basicAWSCredentials = null; s3Client = null;
        logger.error(err.getMessage); throw err
      }
    }
    logger.info("connectToS3 done")
  }
    
   def getS3Client(): AmazonS3Client =  {
         if(null == s3Client) {
            if(isEMRCluster){
              connectS3FromEMR();
            } else{
              connectS3FromLocal(new BasicAWSCredentials("AKIAI6PHGUVBDF4DUUTA", "Ust1vuTfaEZdkmlvZ+ZU2yTjYafrkCeG981GkLBv"));
            }
         }
         s3Client
   }
  
   
   override def getListOfFiles(path:String): List[String] = {
      getS3Client();
     import scala.collection.JavaConversions._
      var listBufffer = ListBuffer[String]()
      val bucket = S3Util.getBucketFromPath(path);
      val prefix = S3Util.getKeyFromPath(path)
      var list = new ListBuffer[String]()
      var listObjectRequest = (new ListObjectsRequest()).withBucketName(bucket).withPrefix(prefix + "/")
      var listOfObjectSummary: List[S3ObjectSummary] = null
      do {
        val objects = s3Client.listObjects(listObjectRequest)
        if (listOfObjectSummary == null || listOfObjectSummary.length == 0) {
          listOfObjectSummary = (objects.getObjectSummaries.toList)
        } else {
          listOfObjectSummary = listOfObjectSummary ++ (objects.getObjectSummaries)
        }

        if (objects.isTruncated()) {
          listObjectRequest.setMarker(objects.getNextMarker)
        } else
          listObjectRequest = null
      } while (listObjectRequest != null)
        
        for (objectSummary <- listOfObjectSummary) {
          val tmpPrefix = prefix + (if (prefix.length() > 0) "/" else "")
          val key = objectSummary.getKey().replace(tmpPrefix, "");
          if (key.endsWith("/")) {
            listBufffer += S3 + bucket + "/" + tmpPrefix + (key.split("/")(0)) + "/"
          } else {
            val s = key.split("/")
            if (!listBufffer.contains(s(0) + "/") && !key.isEmpty())
              listBufffer += S3 + bucket + "/" + tmpPrefix + (s(0)) + (if (s.length > 1) "/" else "")
          }
        }
        
      listBufffer.toSet.toList
   }
}