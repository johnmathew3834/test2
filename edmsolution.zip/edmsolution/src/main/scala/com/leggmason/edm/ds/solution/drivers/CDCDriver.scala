package com.leggmason.edm.ds.solution.drivers

import com.leggmason.edm.ds.framework.context.SparkSessionProvider;
import com.leggmason.edm.ds.framework.driver.BaseDriver;
import com.leggmason.edm.ds.solution.servicesImpl.CDCServiceImpl
import com.leggmason.edm.ds.framework.common.utils.JsonUtil
import com.leggmason.edm.ds.framework.common.constant.PropertyFileConstant
import com.leggmason.edm.ds.framework.common.utils.FileUtil
import com.leggmason.edm.ds.framework.schema.MalFormed;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.catalyst.encoders.RowEncoder

import org.apache.commons.lang3.StringUtils




import org.apache.spark.sql.types.{StructType, StructField, StringType};

//-import org.apache.spark.sql.catalyst.encoders.RowEncoder

object CDCDriver extends BaseDriver with SparkSessionProvider {

  def main(args: Array[String]): Unit = {

    initilize(getSparkSession(this.getClass, args),args)
    new CDCServiceImpl(spark).doService();
    
    
    
   /* val csvRDD = spark.read.option("header", "true").option("inferSchema", true).csv("s3n://genpact-es-poc/Input/bi_salesFact.csv");
    val schema = csvRDD.schema;
    //-val splittedRdd=csvRDD.map(line=>line.toString().split(","));
    //-csvRDD.mapPartitions(processes(_),encoder);
    //-csvRDD.map(x=>x(0),RowEncoder(String));
    val jsonMap = JsonUtil.convertJsonToMapWithValInt(FileUtil.readFileAsString(PropertyFileConstant.CDC_JSON_MAPPING));
    lazy val cleanedRdd = csvRDD.rdd.mapPartitions(testt(_), true);

    def testt(rowIterator: Iterator[org.apache.spark.sql.Row]): Iterator[(Row, String)] = {
      //- import spark.implicits._
      var collect: StringBuilder = null;
      val row = rowIterator.map { row =>
        collect = new StringBuilder();
        if (row.getInt(jsonMap("Zip")) == 29526) {
          collect.append("|zipCode is wrong");
        }

        (row, collect.toString());
      }
      row;

    }
    val invalidRow=cleanedRdd.filter(_._2.length>1).map(x=>Row(x._1.mkString(",").concat(x._2)));
    val validRecord=cleanedRdd.filter(_._2.length==0).map(x=>(x._1));
    
    val a=(x:Int)=>(x% 2==0);
   //- def odd(x): return not even(x)
    //-csvRDD.mapPartitions(processes(_).asInstanceOf[org.apache.spark.sql.Row],encoder);
    //-val errorSchema=StructType(Seq(StructField("record", StringType, true),StructField("error", StringType, true)))
     val errorSchema=StructType(Seq(StructField("error", StringType, true)));
    //-val cleanedRdd = csvRDD.mapPartitions(rows=>process(rows));
    //-csvRDD.mapPartitions(process(_))
    //- csvRDD.write.mode("overwrite").csv("s3n://genpact-es-poc/output4/")
    //-cleanedRdd.collect()
    spark.createDataFrame(validRecord, schema).write.mode("overwrite").csv("s3n://genpact-es-poc/output3/");
    spark.createDataFrame(invalidRow, MalFormed.schema).write.mode("overwrite").csv("s3n://genpact-es-poc/output4/")

    //-val ss = new CDCServiceImpl(getSparkSession(this.getClass,args));
    //-val cleanedRdd1=csvRDD.mapPartitions(processes(_));
  }

  def processes(rowIterator: Iterator[org.apache.spark.sql.Row]): Iterator[Row] = {
    var cleanData = scala.collection.mutable.ListBuffer[Row]();
    rowIterator.map { row =>
      //- if (row.getString(i)=="") {
      cleanData += row;
      //-  }
    }
    cleanData.toList.iterator;*/
  }
}