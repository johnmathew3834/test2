package com.leggmason.edm.ds.framework.common.constant

object DataFrameConstant {
  val inferSchema:Boolean=true;
  val overwrite="overwrite";
  val csv="CSV";
  val json="json";
}