package com.leggmason.edm.ds.framework.common.utils

import java.io.BufferedReader
import java.io.FileReader
import scala.io.Source
import parquet.org.slf4j.LoggerFactory
import java.io.IOException
import java.io.FileNotFoundException

object FileUtil {

  val logger = LoggerFactory.getLogger(this.getClass)
  /**
   * @param sourcePath
   * @return
   */
  def readFileAsString(sourcePath: String): String = {
    var outputString: String = ""
    try {
       outputString = Source.fromInputStream(getClass.getResourceAsStream(sourcePath)).getLines.mkString;
    } catch {
      case fnf: FileNotFoundException => logger.error("File not found : " + sourcePath)
      case io: IOException            => logger.error("IO Exception occurred : " + sourcePath)
      case exc: Exception             => logger.error("Exception occurred : " + sourcePath)
    }
    outputString
  }
}