package com.leggmason.edm.ds.framework.driver

import com.leggmason.edm.ds.framework.context.SparkSessionProvider
import com.leggmason.edm.ds.framework.common.utils.PropertyUtil

import org.apache.spark.sql.SparkSession;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

trait BaseDriver {
  var spark: SparkSession = null;

  @Option(name = "--sourceLocation", usage = "location of source file")
  private var sourceLocation: String = null;

  @Option(name = "--destinationLocation", usage = "location of destination to copy")
  private var destinationLocation: String = null;

  @Option(name = "--source", usage = "which source going to be process")
  protected var source: String = null;
  
  
  def initilize(spark: SparkSession, args: Array[String]) {
    this.spark = spark;
    spark.sparkContext.hadoopConfiguration.set("fs.s3.awsAccessKeyId", "AKIAI6PHGUVBDF4DUUTA")
    spark.sparkContext.hadoopConfiguration.set("fs.s3.awsSecretAccessKey", "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");
    spark.sparkContext.hadoopConfiguration.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")

    //below is for avoid generate success file
    spark.sparkContext.hadoopConfiguration.set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false");

    //Verify command line arguments
      parseArgs(args)
      PropertyUtil.loadProperties(source, "/"+source+ ".properties");
  }

  def parseArgs(args: Array[String]) {

    try {
      val parser = new CmdLineParser(this);
      for (arg <- args) {
        parser.parseArgument(arg);
      }
    } catch {
      case e: CmdLineException => {
        val start = e.getMessage().indexOf('"') + 1;
        val end = e.getMessage().lastIndexOf('"');
        val wrongArgument = e.getMessage().substring(start, end);
        println("Unknown argument: " + wrongArgument);
        println("ant [options] [target [target2 [target3] ...]]");
        //parser.printUsage(System.err);
      }
      //throw new IOException();
    }
  }
}