package com.leggmason.edm.ds.framework.common.utils

import com.leggmason.edm.ds.framework.data.ECLDataType;
import com.leggmason.edm.ds.framework.common.constant.DataFrameConstant;

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession

import org.slf4j.LoggerFactory

object DataFrameUtil {
  val logger = LoggerFactory.getLogger(this.getClass)
  def buildDatFrame(spark: SparkSession, file: String, datatype: ECLDataType): DataFrame = {

    var dataFrame: DataFrame = null
    if (null != datatype) {
      if (datatype.inferschema) {
        if (datatype.sourceFileType == DataFrameConstant.csv) {
          logger.info("dataframe file...."+file);
          dataFrame = spark.read.option("header", "true").option("inferSchema", true).csv(file);
        } else if (datatype.sourceFileType == DataFrameConstant.json) {
          dataFrame = spark.read.json(file);
        } else {
          spark.read.parquet(file)
        }
      }
    }
    dataFrame;
  }
}