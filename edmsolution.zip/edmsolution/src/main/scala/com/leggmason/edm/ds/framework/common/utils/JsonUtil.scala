package com.leggmason.edm.ds.framework.common.utils

import com.fasterxml.jackson.databind.{JsonNode,ObjectMapper,SerializationFeature};
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.module.scala.DefaultScalaModule;
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.annotation._;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.File;

import org.json4s._
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods._



object JsonUtil {
  implicit val formats = DefaultFormats
  val mapper = new ObjectMapper();
  /*val objectMapper = new ObjectMapper() with ScalaObjectMapper;
  objectMapper.registerModule(DefaultScalaModule);
  objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
   def parseJson[T](jsonData : String)(implicit m:Manifest[T]):T = {
     objectMapper.readValue[T](jsonData);
   }
   
   def toMap[V](json:String)(implicit m: Manifest[V])=parseJson[Map[String,V]](json)*/
  
  def convertJsonToMap(json:String):Map[String,String]={
    val jsValue = parse(json,true);
    jsValue.extract[Map[String,String]]
    //objectMapper.readValue(json, classOf[Map[String,String]]);
  }
  
  def convertJsonToMapWithValInt(json:String):Map[String,Int]={
    val jsValue = parse(json,true);
    jsValue.extract[Map[String,Int]]
    //objectMapper.readValue(json, classOf[Map[String,String]]);
  }
  
  def convertJsonToObject(jsonFileLocation:String, clazz:Class[_]):Object= {
     
        try {
            val  json  =  mapper.readValue(FileUtil.readFileAsString(jsonFileLocation),clazz);
            return json.asInstanceOf[Object];
        } catch {
          case e:IOException =>   println("IO Exception -- "+ e.printStackTrace());
          case e:Exception =>   println("Exception -- "+ e.printStackTrace());
        }
        null;
  }
  
}