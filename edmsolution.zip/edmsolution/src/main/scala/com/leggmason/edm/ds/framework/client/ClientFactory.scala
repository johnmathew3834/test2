package com.leggmason.edm.ds.framework.client

import scala.io.Source
import java.io.File
import com.leggmason.edm.ds.framework.common.constant.AWSConstant

object ClientFactory {  
  
      def getClient(env:String): ClientHandler =  {
         S3Client;
      }
  
}