package com.leggmason.edm.ds.framework.validation

import org.apache.commons.lang3.StringUtils

object CommonValidator extends BaseValidator {
  
  def isNull(data:Object) : Boolean = {
    if(data==null)true else false;
  }
  
  def isEmpty(data:String) : Boolean ={
     StringUtils.isEmpty(data);
  }
  
  def isBlank(data:String) : Boolean ={
     StringUtils.isBlank(data);
  }
   
   def isAlphaNumeric(data:String) : Boolean ={
     StringUtils.isAlphanumeric(data);
  }
   
   
  
}