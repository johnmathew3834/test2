package com.leggmason.gd.edm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;

/**
 * Created by himanshu on 8/20/2017.
 * Class used to create object schema using input json file.
 */
public class ObjectSchemaCreator {

    private static ObjectSchema objectSchema;

    private static final Logger LOGGER = Logger.getLogger(ObjectSchemaCreator.class);

    /**
     * Provides a Singleton Instance of Object Schema Bean
     *
     * @param jsonFilePath - Input path where object JSON file exists
     * @return - ObjectSchema
     * @throws IOException
     */
    public static ObjectSchema getObjectSchema(String jsonFilePath) throws IOException {
        if (objectSchema == null) {

            ObjectMapper mapper = new ObjectMapper();
            try {
                objectSchema = mapper.readValue(new File(jsonFilePath), ObjectSchema.class);

                LOGGER.info("Schema Size is " + objectSchema.getSchema().size());
                return objectSchema;
            } catch (IOException e) {
                LOGGER.error("Exception Occurred", e);
                throw e;
            }
        } else {
            return objectSchema;
        }
    }


}
