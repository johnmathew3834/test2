package com.stream.driver

import com.stream.extractor.TwiterExtractor

object ExtractDriver {
  def main(args: Array[String]): Unit = {
    val extractor = new TwiterExtractor();
    extractor.init();
    extractor.extract();
  }
}