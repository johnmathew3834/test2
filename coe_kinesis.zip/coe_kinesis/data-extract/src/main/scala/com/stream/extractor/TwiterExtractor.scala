package com.stream.extractor

import twitter4j._

//import scala.collection.JavaConversions._
import scala.collection.JavaConverters._
import collection.mutable._

import twitter4j.auth.AccessToken;
import com.coe.stream.service.aws.KinesisProducer
//import scala.collection.mutable.ListBuffer
import twitter4j.Query.ResultType


class TwiterExtractor {

  var twitter:Twitter=null

  def init(): Unit ={
    val twitter:Twitter = new TwitterFactory().getInstance();
    //twitter.setOAuthConsumer(consumerKeyStr, consumerSecretStr);
    twitter.setOAuthConsumer("bjgvkucetOGwktMO4khkE74Kd", "YcIIBebQy8FQrHse5ZXGxU7AtbGho4St0M5jgyhSXgy2coxf81");
    //val accessToken: AccessToken = new AccessToken(accessTokenStr,accessTokenSecretStr);
    val accessToken: AccessToken = new AccessToken("354075464-uBa3t90VteDuThNCUOXXG859ZhYs7KdrM6MTXUFK","l06EqBSfkSSShzzE9D31bJmMcivUfro6h8fwOjck15T7g");

    // (2) use the twitter object to get your friend's timeline
    twitter.setOAuthAccessToken(accessToken);

    this.twitter=twitter;
  }

  def extract() = {
    getTrends()
//getTweets()
  }

  def getTweets() = {
    val url = "https://stream.twitter.com/1.1/statuses/filter.json";
	  val query_data = List(("language", "en"), ("locations", "-130,-20,100,50"),("track","#"));
	  val query_url = url + "?" + (for((k,v) <- query_data) yield k+"="+v).mkString("&")
	  val query:Query = new Query("#");
	  query.setLang("en")
	  val location:GeoLocation = new GeoLocation("-130,-20".toDouble, "100,50".toDouble);
	  query.setGeoCode(location, 200, Query.KILOMETERS)
	  query.setCount(10001)
	  val results = twitter.trends().getAvailableTrends
    //resultls.
    System.out.println("Showing friends timeline.")
    for(status <- results.asScala){

      println(status.getName+"^^^^^^^^^^^^^^^^^^"+status.getCountryName+"^^^^^^^^^^^^^^^^^^"+status.getPlaceName+"^^^^^^^^^^^^^^^^^^"+status.getURL)
  }
  }
  
  
  
  def getTrends() = {
    val query:Query = new Query();
     val hashTagLst = List("suresh","india","politics","politician","sports","art","cricket","nature","toruism","protect","election","marketing","technology","belief","music","olympics","t20","pets","festivel","friends","photography","AI","COVID","event","contest","coronavirus","covid19","vaccine","facemask")
    query.setCount(10001)
    query.setLang("en")
    query.resultType(ResultType.recent);
    var i:Int=0;
    var lst:ListBuffer[String]=ListBuffer();
    val producer:KinesisProducer = new KinesisProducer("twitter_data", "us-east-1", "partitionKey-1");
    var a:Int=1;
    //var rateLimitStatus:Map[String, RateLimitStatus] = twitter.getRateLimitStatus("search");
    var searchTweetsRateLimit:Option[RateLimitStatus] = Some(twitter.getRateLimitStatus("search").get("/search/tweets"));
    while(a<10){
      println("searchTweetsRateLimit.get.getRemaining : "+searchTweetsRateLimit.get.getRemaining)
      if (searchTweetsRateLimit.get.getRemaining == 0){
          Thread.sleep(searchTweetsRateLimit.get.getSecondsUntilReset() * 1000L);
      }
    query.setQuery(hashTagLst(i))
    val result :QueryResult = twitter.search(query)
    //val resultls = twitter.trends().getAvailableTrends    
    System.out.println("Showing friends timeline.''''''")
    for(status:Status <- result.getTweets().asScala){
      if(status.getText.contains("#")){
        //System.out.println("HashTag : "+hashTagLst(i))
   val hashtagEntities:Array[HashtagEntity] = status.getHashtagEntities();
     //println(status.getText)
       if (hashtagEntities != null && hashtagEntities.length > 0) {
          val s:StringBuilder = new StringBuilder();
           // s.append(hashtagEntities[0].getText());
     for(hs <- hashtagEntities) {
       if(!hs.getText.contains("?"))
       lst+=hs.getText.toString()
      //s.append(hs.getText);
    }
   
     /*Arrays.stream(status.getHashtagEntities()).map(hashtag -> new Token(
      "#" + hashtag.getText(),
      hashtag.getStart(),
      hashtag.getEnd(),
      Token.TokenType.CLICKABLE,
      () -> browserSupport.openUrl(HASHTAG_SEARCH_BASE_URL + hashtag.getText())
  )).collect(Collectors.toList());*/
      //println(s.toString)
     if(lst.size>=2000){
     producer.pushRecords(lst.asJava);
     lst=ListBuffer();
     Thread.sleep(5000);
     println("I'm Sleeping 5 seconds")
     }
       }
    }
    }
    i+=1;
    if(i>=hashTagLst.size){
      i=0;
    }
    searchTweetsRateLimit = Some(result.getRateLimitStatus());
  }
     /*for(status <- resultls){

      println(status.getName+"^^^^^^^^^^^^^^^^^^"+status.getCountryName+"^^^^^^^^^^^^^^^^^^"+status.getPlaceName+"^^^^^^^^^^^^^^^^^^"+status.getURL)
  }*/
    
  }
  def destroy(): Unit ={

  }
}

