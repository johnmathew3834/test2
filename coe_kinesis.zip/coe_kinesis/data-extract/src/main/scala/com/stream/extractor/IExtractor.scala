package com.stream.extractor

trait IExtractor {
  def init(): AnyRef;
  def extract(any:AnyRef): Unit;

}