package com.coe.stream.service.aws.kinesis.common_kinesis;

import java.util.ArrayList;
import java.util.List;

import com.coe.stream.service.aws.KinesisProducer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        List<String> lst = new ArrayList<String>();
        lst.add("123");
        
        
        new KinesisProducer("twitter_data", "us-east-1", "partitionKey-1").pushRecords(lst);
    }
}
