package com.coe.stream.service.aws;

import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.PutRecordsRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.PutRecordsResult;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class KinesisProducer {

    private String streamName;
    private String region;
    private String partitionKey;
    private static AmazonKinesis kinesisClient = null;
    private static AmazonKinesis client = null;
	
	public static AmazonKinesis getConnection() {
		if(null == client) {
			client = AmazonKinesisClientBuilder.standard().withRegion("us-east-1").build();
		}
		return client;
	}

    private void init(){       
        kinesisClient = AmazonKinesisClientBuilder.standard().withRegion(this.region).build();
    }
    public KinesisProducer(String streamName, String region, String partitionKey) {
        this(streamName, region, partitionKey,"");
    }

    public KinesisProducer(String streamName, String region, String partitionKey, String authenticationMethod) {
        this.streamName = streamName;
        this.region = region;
        this.partitionKey = partitionKey;
        //this.authenticationMethod = authenticationMethod;
        init();

    }


    public void pushRecords(List<String> records){
    	System.out.println("records list size : "+records.size());
    	final List<PutRecordsRequestEntry> list = Collections.emptyList();
        int numShards = kinesisClient.describeStream(streamName).getStreamDescription().getShards().size();
        PutRecordsRequest putRecordsRequest = new PutRecordsRequest();
        putRecordsRequest.setStreamName(streamName);
        List<PutRecordsRequestEntry> putRecordsRequestEntryList  = new ArrayList<>(); 
        int i=1;   
        PutRecordsResult putRecordsResult=null;
        for (String msg: records) {
        	System.out.println(msg);        	
            PutRecordsRequestEntry putRecordsRequestEntry  = new PutRecordsRequestEntry();
            putRecordsRequestEntry.setData(ByteBuffer.wrap(msg.getBytes()));
            putRecordsRequestEntry.setPartitionKey(String.format("partitionKey-%d",i));
            putRecordsRequestEntryList.add(putRecordsRequestEntry); 
            if(i%400==0 || i==records.size()) {
            	System.out.println("putRecordsRequestEntryList list size : "+putRecordsRequestEntryList.size());
            	putRecordsRequest.setRecords(putRecordsRequestEntryList);
                putRecordsResult  = kinesisClient.putRecords(putRecordsRequest);
                putRecordsRequestEntryList  = new ArrayList<>(); 
            }
            /*if (null  != putRecordsResult && putRecordsResult.getFailedRecordCount()>0) {
            	unProcessedDataHandler.unprocessedKinesisData(putRecordsResult);
            }*/
            System.out.println("i size "+i);
            i++;
        }
       // PutRecordsResult putRecordsResult = kinesisClient.putRecords(putRecordsRequest);
    }
}
